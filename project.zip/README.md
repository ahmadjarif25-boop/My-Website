# BD News Hub

This is a Next.js application that aggregates news from various Bangladeshi online newspapers, providing AI-powered summaries and personalized feeds.

To get started, take a look at `src/app/page.tsx`.
