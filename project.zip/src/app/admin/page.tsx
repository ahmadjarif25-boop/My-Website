'use client';

import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import { Header } from '@/components/header';
import { SidebarNav } from '@/components/sidebar-nav';
import { Suspense, useEffect } from 'react';
import PageLoading from '../loading';
import { Shield, ShieldX, Newspaper, Users, BarChart, Bell, BadgePercent, Puzzle, Tv, Crown, Mail, MessageSquare } from 'lucide-react';
import { useUser, useDoc, useFirestore, useMemoFirebase } from '@/firebase';
import { useRouter } from 'next/navigation';
import { doc } from 'firebase/firestore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { UserManagementTable } from '@/components/admin/user-management-table';
import { SourceManagement } from '@/components/admin/source-management';
import { AnalyticsDashboard } from '@/components/admin/analytics-dashboard';
import { AdManagement } from '@/components/admin/ad-management';
import { NotificationCenter } from '@/components/admin/notification-center';
import { QuizCreator } from '@/components/admin/quiz-creator';
import Link from 'next/link';
import { TVChannelManagement } from '@/components/admin/tv-channel-management';
import { SubscriptionManagement } from '@/components/admin/subscription-management';
import { SubmissionManagement } from '@/components/admin/submission-management';
import { FeedbackManagement } from '@/components/admin/feedback-management';

export default function AdminPage() {
  const { user, isUserLoading } = useUser();
  const router = useRouter();
  const firestore = useFirestore();

  const adminRoleRef = useMemoFirebase(() => {
    if (!user) return null;
    return doc(firestore, 'roles_admin', user.uid);
  }, [firestore, user]);

  const { data: adminRole, isLoading: isAdminRoleLoading } = useDoc(adminRoleRef);

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push('/admin/login');
    }
  }, [user, isUserLoading, router]);

  if (isUserLoading || !user || isAdminRoleLoading) {
    return <PageLoading />;
  }

  const isAdmin = !!adminRole;

  return (
    <Suspense fallback={<PageLoading />}>
      <SidebarProvider>
        <SidebarNav />
        <SidebarInset>
          <Header />
          <main className="min-h-screen bg-muted/40 p-4 sm:p-6 lg:p-8">
            <div className="mb-8">
               <h1 className="text-3xl font-bold flex items-center gap-2 text-primary">
                <Shield className="w-8 h-8" />
                Admin Dashboard
              </h1>
              <p className="text-muted-foreground">Manage your application's sources, content, and users.</p>
            </div>
            
            {!isAdmin ? (
               <div className="rounded-lg border bg-card text-card-foreground shadow-sm border-destructive/50 p-12 text-center h-[60vh] flex flex-col items-center justify-center">
                <ShieldX className="h-12 w-12 text-destructive" />
                <h3 className="mt-4 text-lg font-semibold">Access Denied</h3>
                <p className="mt-2 text-sm text-muted-foreground max-w-md">
                  You do not have the necessary permissions to view this page. Please log in as an administrator.
                </p>
                <Link href="/admin/login" className="mt-6 text-sm font-medium text-primary hover:underline">
                  Go to Admin Login
                </Link>
              </div>
            ) : (
              <Tabs defaultValue="overview" className="w-full">
                <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 lg:grid-cols-11 h-auto">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="sources"><Newspaper className="w-4 h-4 mr-2"/>Sources</TabsTrigger>
                  <TabsTrigger value="tv-channels"><Tv className="w-4 h-4 mr-2"/>TV Channels</TabsTrigger>
                  <TabsTrigger value="submissions"><Mail className="w-4 h-4 mr-2"/>Submissions</TabsTrigger>
                  <TabsTrigger value="feedback"><MessageSquare className="w-4 h-4 mr-2"/>Feedback</TabsTrigger>
                  <TabsTrigger value="users"><Users className="w-4 h-4 mr-2"/>Users</TabsTrigger>
                  <TabsTrigger value="analytics"><BarChart className="w-4 h-4 mr-2"/>Analytics</TabsTrigger>
                  <TabsTrigger value="notifications"><Bell className="w-4 h-4 mr-2"/>Notifications</TabsTrigger>
                  <TabsTrigger value="ads"><BadgePercent className="w-4 h-4 mr-2"/>Ads</TabsTrigger>
                  <TabsTrigger value="subscriptions"><Crown className="w-4 h-4 mr-2"/>Subscriptions</TabsTrigger>
                  <TabsTrigger value="quizzes"><Puzzle className="w-4 h-4 mr-2"/>Quizzes</TabsTrigger>
                </TabsList>
                
                <TabsContent value="overview" className="mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Overview</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">High-level statistics about your app will be displayed here.</p>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="sources" className="mt-4">
                  <SourceManagement />
                </TabsContent>
                
                <TabsContent value="tv-channels" className="mt-4">
                  <TVChannelManagement />
                </TabsContent>

                <TabsContent value="submissions" className="mt-4">
                  <SubmissionManagement />
                </TabsContent>

                <TabsContent value="feedback" className="mt-4">
                  <FeedbackManagement />
                </TabsContent>

                <TabsContent value="users" className="mt-4">
                   <Card>
                    <CardHeader>
                      <CardTitle>User Management</CardTitle>
                       <p className="text-sm text-muted-foreground pt-1">View and manage user roles in the application. You can assign roles like 'Admin', 'Editor', or 'Moderator' to different users to give them specific permissions.</p>
                    </CardHeader>
                    <CardContent>
                       <UserManagementTable />
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="analytics" className="mt-4">
                    <AnalyticsDashboard />
                </TabsContent>
                
                <TabsContent value="notifications" className="mt-4">
                    <NotificationCenter />
                </TabsContent>

                <TabsContent value="ads" className="mt-4">
                    <AdManagement />
                </TabsContent>

                <TabsContent value="subscriptions" className="mt-4">
                    <SubscriptionManagement />
                </TabsContent>
                
                <TabsContent value="quizzes" className="mt-4">
                    <QuizCreator />
                </TabsContent>

              </Tabs>
            )}
          </main>
        </SidebarInset>
      </SidebarProvider>
    </Suspense>
  );
}
