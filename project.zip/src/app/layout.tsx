import type { Metadata } from 'next';
import { Toaster } from "@/components/ui/toaster"
import './globals.css';
import { FirebaseClientProvider } from '@/firebase/client-provider';
import { Inter, Noto_Sans_Bengali } from 'next/font/google';
import { cn } from '@/lib/utils';
import Link from 'next/link';
import { ThemeProvider } from '@/components/theme-provider';

export const metadata: Metadata = {
  title: 'BD News Hub',
  description: 'Your central source for Bangladeshi news, with AI-powered summaries and personalized feeds.',
};

const fontSans = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
});

const fontBengali = Noto_Sans_Bengali({
  subsets: ['bengali'],
  variable: '--font-bengali',
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={cn("font-sans antialiased", fontSans.variable, fontBengali.variable)}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <FirebaseClientProvider>
            <div className="flex min-h-screen flex-col">
              <main className="flex-grow">{children}</main>
              <footer className="bg-muted py-6 px-4 md:px-6">
                  <div className="container mx-auto flex flex-col md:flex-row items-center justify-between">
                      <p className="text-sm text-muted-foreground">
                          © {new Date().getFullYear()} BD News Hub. All rights reserved.
                      </p>
                      <nav className="flex gap-4 sm:gap-6 mt-4 md:mt-0">
                          <Link href="/terms" className="text-sm hover:underline underline-offset-4 text-muted-foreground">
                              Terms of Service
                          </Link>
                          <Link href="/privacy" className="text-sm hover:underline underline-offset-4 text-muted-foreground">
                              Privacy Policy
                          </Link>
                      </nav>
                  </div>
              </footer>
            </div>
          </FirebaseClientProvider>
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
