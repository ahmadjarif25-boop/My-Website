import { Logo } from '@/components/icons';

export default function PageLoading() {
  return (
    <div className="flex h-screen w-screen items-center justify-center bg-background">
      <div className="relative flex h-32 w-32 items-center justify-center">
        <div className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75"></div>
        <div className="absolute inline-flex h-full w-full animate-pulse rounded-full bg-primary opacity-25"></div>
        <Logo className="relative h-28 w-28 text-primary" />
      </div>
    </div>
  );
}
