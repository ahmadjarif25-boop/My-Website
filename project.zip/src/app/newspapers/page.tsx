'use client';

import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import { Header } from '@/components/header';
import { SidebarNav } from '@/components/sidebar-nav';
import { Suspense, useMemo } from 'react';
import PageLoading from '../loading';
import { Newspaper, NewspaperCategory, newspaperCategoryMap } from '@/lib/types';
import { Frown } from 'lucide-react';
import { DistrictFilter } from '@/components/district-filter';
import { SearchInput } from '@/components/search';
import { NewspaperCard } from '@/components/newspaper-card';
import { useSearchParams } from 'next/navigation';
import { useCollection, useFirestore, useMemoFirebase } from '@/firebase';
import { collection } from 'firebase/firestore';
import { newspapersData as staticNewspapersData } from '@/lib/newspapers-data';
import { districtsData } from '@/lib/districts-data';

function NewspapersContent() {
  const searchParams = useSearchParams();
  const firestore = useFirestore();

  const sourcesQuery = useMemoFirebase(() => collection(firestore, 'sources'), [firestore]);
  const { data: firestoreSources, isLoading } = useCollection<Omit<Newspaper, 'websiteUrl' | 'id'> & { rssLink: string; id: string }>(sourcesQuery);

  const newspapersData: Newspaper[] = useMemo(() => {
    const allNewspapers = new Map<string, Newspaper>();

    // Add static data first.
    staticNewspapersData.forEach(paper => {
      allNewspapers.set(paper.name, { ...paper, isActive: paper.isActive === undefined ? true : paper.isActive });
    });

    // Add/overwrite with Firestore data
    if (firestoreSources) {
      firestoreSources.forEach(source => {
        const newspaper: Newspaper = {
          ...source,
          // Ensure `isActive` property exists, defaulting to true if not present in firestore doc
          isActive: source.isActive === undefined ? true : source.isActive,
          websiteUrl: source.rssLink,
        };
        // Use name to overwrite static data with firestore data
        allNewspapers.set(source.name, newspaper);
      });
    }
    
    return Array.from(allNewspapers.values());
  }, [firestoreSources]);


  const selectedCategory = searchParams.get('category') || 'All';
  const searchQuery = searchParams.get('q')?.toLowerCase() || '';
  const selectedDistrict = searchParams.get('district');

  if (isLoading) {
    return <PageLoading />;
  }
  
  const getFilteredNewspapers = (): Newspaper[] => {
    let filtered = newspapersData.filter(paper => paper.isActive !== false && paper.name.toLowerCase() !== 'avvc');

    if (selectedCategory && selectedCategory !== 'All') {
      filtered = filtered.filter(paper => paper.category === selectedCategory);
    }
    
    if (searchQuery) {
        filtered = filtered.filter(paper =>
          paper.name.toLowerCase().includes(searchQuery) ||
          (paper.nameBn && paper.nameBn.toLowerCase().includes(searchQuery))
        );
    } else if (selectedCategory === 'Local' && selectedDistrict && selectedDistrict !== 'All') {
      // Only apply district filter if not searching
      filtered = filtered.filter(paper => paper.district === selectedDistrict);
    }

    return filtered;
  }

  const filteredNewspapers = getFilteredNewspapers();
  const districts = districtsData.map(d => d.name).sort();

  const NoResults = () => (
    <div className="flex flex-col items-center justify-center rounded-lg border border-dashed p-12 text-center h-[40vh] bg-card col-span-full">
      <Frown className="mx-auto h-12 w-12 text-muted-foreground" />
      <h3 className="mt-4 text-lg font-semibold">No Newspapers Found</h3>
      <p className="mt-2 text-sm text-muted-foreground">
        No newspapers found for the selected criteria. Try adjusting your filters or adding new sources in the admin panel.
      </p>
    </div>
  );
  
  const groupedNewspapers = filteredNewspapers.reduce((acc, newspaper) => {
    const categoryKey = newspaper.category;
    if (!acc[categoryKey]) {
      acc[categoryKey] = [];
    }
    acc[categoryKey].push(newspaper);
    return acc;
  }, {} as Record<string, Newspaper[]>);
  
  const categoryOrder: NewspaperCategory[] = ['National', 'Local', 'English'];

  const categoriesToShow = (selectedCategory && selectedCategory !== 'All' && !searchQuery)
    ? [selectedCategory]
    : Object.keys(groupedNewspapers).sort((a, b) => {
        const indexA = categoryOrder.indexOf(a as NewspaperCategory);
        const indexB = categoryOrder.indexOf(b as NewspaperCategory);
        
        // If both are not in the custom order, sort them alphabetically
        if (indexA === -1 && indexB === -1) return a.localeCompare(b);
        // If only A is not in the custom order, it should come after B
        if (indexA === -1) return 1;
        // If only B is not in the custom order, it should come after A
        if (indexB === -1) return -1;
        
        // Both are in the custom order, sort by their index
        return indexA - indexB;
      });

  const pageTitle = (selectedCategory && selectedCategory !== 'All')
    ? newspaperCategoryMap[selectedCategory as keyof typeof newspaperCategoryMap] 
    : "All Newspapers";


  return (
      <main className="p-4 sm:p-6 lg:p-8 min-h-screen">
        <div className="mb-8">
          <div className="flex w-full flex-wrap items-center justify-between gap-4">
              <div className="flex-grow">
                <h1 className="text-3xl font-bold tracking-tight text-primary">{pageTitle}</h1>
              </div>
              <div className="w-full sm:w-auto">
                <SearchInput />
              </div>
          </div>
        </div>
        
        {filteredNewspapers.length === 0 ? <NoResults /> : (
          (categoriesToShow).map((category) => {
              const papersInCategory = groupedNewspapers[category];
              if (!papersInCategory || papersInCategory.length === 0) {
                  return null;
              }
              return (
                  <div key={category} className="mb-12">
                      <div className="flex items-center justify-between mb-6 border-b pb-2">
                        <h2 className="text-2xl font-bold tracking-tight text-primary">{newspaperCategoryMap[category as keyof typeof newspaperCategoryMap] || category}</h2>
                        {category === 'Local' && <DistrictFilter districts={districts} />}
                      </div>
                    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
                      {papersInCategory.map((newspaper: Newspaper) => (
                        <NewspaperCard newspaper={newspaper} key={newspaper.name} />
                      ))}
                    </div>
                  </div>
              )
          })
        )}
      </main>
  );
}

export default function NewspapersPage() {
  return (
    <Suspense fallback={<PageLoading />}>
      <SidebarProvider>
        <SidebarNav />
        <SidebarInset>
          <Header />
          <NewspapersContent />
        </SidebarInset>
      </SidebarProvider>
    </Suspense>
  );
}
