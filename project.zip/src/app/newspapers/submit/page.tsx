'use client';

import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import { Header } from '@/components/header';
import { SidebarNav } from '@/components/sidebar-nav';
import { Suspense, useEffect, useState } from 'react';
import PageLoading from '@/app/loading';
import { useFirestore, useUser, uploadFileAndGetURL, useStorage } from '@/firebase';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { newspaperCategories, SubmittedSource } from '@/lib/types';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, Controller } from 'react-hook-form';
import { z } from 'zod';
import { PlusCircle, Send, Image as ImageIcon } from 'lucide-react';
import { collection, doc, serverTimestamp, setDoc } from 'firebase/firestore';
import { districtsData } from '@/lib/districts-data';
import { compressImage } from '@/lib/utils';
import { Progress } from '@/components/ui/progress';

const submissionSchema = z.object({
  mediaName: z.string().min(3, { message: 'Media name must be at least 3 characters.' }),
  mediaLink: z.string().url({ message: 'Please enter a valid URL.' }),
  sourceCategory: z.enum(newspaperCategories, { required_error: 'Please select a category.' }),
  district: z.string().optional(),
  districtBn: z.string().optional(),
  ownerContact: z.string().min(5, { message: 'Contact information is required.' }),
  logoUrl: z.string().url({ message: 'Please enter a valid URL.' }).optional().or(z.literal('')),
  logoFile: z.any().optional(),
}).refine(data => data.sourceCategory !== 'Local' || !!data.district, {
    message: "District is required for Local newspapers.",
    path: ["district"],
}).refine(data => !!data.logoUrl || (data.logoFile && data.logoFile.length > 0), {
    message: "Please provide a logo URL or upload a logo file.",
    path: ["logoUrl"],
});

type SubmissionFormValues = z.infer<typeof submissionSchema>;

function SubmitNewspaperContent() {
  const { user, isUserLoading } = useUser();
  const router = useRouter();
  const firestore = useFirestore();
  const storage = useStorage();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);

  const { register, handleSubmit, control, watch, setValue, formState: { errors } } = useForm<SubmissionFormValues>({
    resolver: zodResolver(submissionSchema),
    defaultValues: {
        logoUrl: '',
        logoFile: null,
    }
  });

  const sourceCategory = watch('sourceCategory');
  const logoFile = watch('logoFile');
  const logoUrl = watch('logoUrl');

  useEffect(() => {
    const file = logoFile?.[0];
    if (file instanceof File) {
      const newPreviewUrl = URL.createObjectURL(file);
      setLogoPreview(newPreviewUrl);
      
      return () => URL.revokeObjectURL(newPreviewUrl);
    } else if (logoUrl) {
      setLogoPreview(logoUrl);
    } else {
      setLogoPreview(null);
    }
  }, [logoFile, logoUrl]);

  useEffect(() => {
    if (!isUserLoading && !user) {
      toast({
        title: 'Authentication Required',
        description: 'You need to be logged in to submit a newspaper.',
        variant: 'destructive',
      });
      router.push('/login');
    }
  }, [user, isUserLoading, router, toast]);

  const handleDistrictChange = (districtName: string) => {
    const selectedDistrict = districtsData.find(d => d.name === districtName);
    if (selectedDistrict) {
        setValue('district', selectedDistrict.name);
        setValue('districtBn', selectedDistrict.nameBn);
    } else {
        setValue('district', '');
        setValue('districtBn', '');
    }
  };

  const onSubmit = async (data: SubmissionFormValues) => {
    if (!user) return;
    setIsSubmitting(true);
    setUploadProgress(null);

    try {
        let finalLogoUrl = data.logoUrl || '';
        const logoFile = data.logoFile?.[0];

        if (logoFile instanceof File) {
            const compressedFile = await compressImage(logoFile, { maxWidth: 512, quality: 0.8 });
            const uploadPath = `logos/submissions/${Date.now()}_${compressedFile.name}`;
            finalLogoUrl = await uploadFileAndGetURL(storage, compressedFile, uploadPath, setUploadProgress);
            setUploadProgress(100);
        }

        if (!finalLogoUrl) {
            toast({
                variant: "destructive",
                title: "Logo Required",
                description: "Please provide a logo URL or upload a file.",
            });
            setIsSubmitting(false);
            return;
        }

        const submissionId = doc(collection(firestore, 'submitted_sources')).id;
        const newSubmissionRef = doc(firestore, 'submitted_sources', submissionId);
        const userSubmissionDocRef = doc(firestore, 'users', user.uid, 'submissions', submissionId);
        
        const finalSubmissionData: SubmittedSource = {
            id: submissionId,
            userId: user.uid,
            userDisplayName: user.displayName || 'Anonymous',
            userEmail: user.email || '',
            mediaName: data.mediaName,
            mediaLink: data.mediaLink,
            sourceCategory: data.sourceCategory,
            district: data.district || '',
            districtBn: data.districtBn || '',
            ownerContact: data.ownerContact,
            logoUrl: finalLogoUrl,
            status: 'pending' as const,
            submittedAt: serverTimestamp(),
        };
        
        await setDoc(newSubmissionRef, finalSubmissionData);
        await setDoc(userSubmissionDocRef, finalSubmissionData);

        toast({
            title: 'Submission Successful!',
            description: 'Your newspaper has been submitted for review.',
        });
        router.push('/profile');

    } catch (error: any) {
        console.error("Submission failed:", error);
        toast({
            title: 'Submission Failed',
            description: error.message || 'An unexpected error occurred. Please try again.',
            variant: 'destructive',
        });
    } finally {
        setIsSubmitting(false);
        setUploadProgress(null);
    }
  };
  
  if (isUserLoading || !user) {
    return <PageLoading />;
  }
  
  return (
    <main className="p-4 sm:p-6 lg:p-8 min-h-screen">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-primary">
            <PlusCircle />
            Submit Your Newspaper
          </CardTitle>
          <CardDescription>
            Help us enrich our collection. Our team will review the information you provide.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="mediaName">Media Name</Label>
              <Input id="mediaName" placeholder="e.g., The Daily Campus" {...register('mediaName')} disabled={isSubmitting} />
              {errors.mediaName && <p className="text-sm text-destructive">{errors.mediaName.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="mediaLink">Media Link (Website/Facebook Page)</Label>
              <Input id="mediaLink" placeholder="https://example.com" {...register('mediaLink')} disabled={isSubmitting} />
              {errors.mediaLink && <p className="text-sm text-destructive">{errors.mediaLink.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="sourceCategory">Source Category</Label>
              <Controller
                name="sourceCategory"
                control={control}
                render={({ field }) => (
                  <Select onValueChange={field.onChange} defaultValue={field.value} disabled={isSubmitting}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      {newspaperCategories.map(cat => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
              {errors.sourceCategory && <p className="text-sm text-destructive">{errors.sourceCategory.message}</p>}
            </div>

            {sourceCategory === 'Local' && (
                <div className="space-y-2">
                    <Label htmlFor="district">District</Label>
                    <Controller
                        name="district"
                        control={control}
                        render={({ field }) => (
                            <Select onValueChange={(value) => {
                                field.onChange(value);
                                handleDistrictChange(value);
                            }} defaultValue={field.value} disabled={isSubmitting}>
                                <SelectTrigger>
                                    <SelectValue placeholder="Select a district" />
                                </SelectTrigger>
                                <SelectContent>
                                    {districtsData.map(d => <SelectItem key={d.name} value={d.name}>{d.name} ({d.nameBn})</SelectItem>)}
                                </SelectContent>
                            </Select>
                        )}
                    />
                    {errors.district && <p className="text-sm text-destructive">{errors.district.message}</p>}
                </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="ownerContact">Your Contact (Email or Phone)</Label>
              <Input id="ownerContact" placeholder="So we can reach out if needed" {...register('ownerContact')} disabled={isSubmitting} />
              {errors.ownerContact && <p className="text-sm text-destructive">{errors.ownerContact.message}</p>}
            </div>
            
            <Card className="p-4 bg-muted/50">
              <CardHeader className="p-0 pb-4">
                <CardTitle className="text-lg">Newspaper Logo</CardTitle>
                <CardDescription>Upload a file directly or provide an image link. If you see the logo in the preview, it has been added correctly.</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                  <div className="space-y-4">
                     <div className="space-y-2">
                        <Label htmlFor="logoFile">Upload from device (Recommended)</Label>
                        <Input id="logoFile" type="file" accept="image/*" {...register('logoFile')} disabled={isSubmitting} />
                        {uploadProgress !== null && uploadProgress < 100 && (
                            <div className="mt-2">
                                <Progress value={uploadProgress} className="w-full" />
                                <p className="text-xs text-muted-foreground mt-1 text-center">{Math.round(uploadProgress)}% Uploaded</p>
                            </div>
                        )}
                        <p className="text-xs text-muted-foreground pt-1">
                          The most reliable method. We will optimize your image for faster uploads.
                        </p>
                    </div>

                    <div className="relative my-2 flex items-center justify-center">
                        <div className="absolute inset-0 flex items-center"><span className="w-full border-t" /></div>
                        <div className="relative flex justify-center text-xs uppercase"><span className="bg-muted/50 px-2 text-muted-foreground">OR</span></div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="logoUrl">Provide direct image link</Label>
                      <Input id="logoUrl" placeholder="https://.../logo.png" {...register('logoUrl')} />
                       <p className="text-xs text-muted-foreground pt-1">
                        Right-click on the image and use "Copy Image Address".
                      </p>
                    </div>
                  </div>
                  <div className="flex justify-center items-center h-48 rounded-md border-2 border-dashed bg-background">
                     {logoPreview ? (
                        <img src={logoPreview} alt="Logo Preview" className="max-h-full max-w-full object-contain p-2" />
                      ) : (
                        <div className="text-center text-muted-foreground">
                          <ImageIcon className="mx-auto h-10 w-10" />
                          <p className="mt-2 text-sm">Logo Preview</p>
                        </div>
                      )}
                  </div>
                </div>
                 {(errors.logoFile || errors.logoUrl) && !logoPreview && <p className="text-sm text-destructive mt-4">Please upload a logo file or provide a valid URL.</p>}
              </CardContent>
            </Card>

            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? 'Submitting...' : 'Submit for Review'}
              {!isSubmitting && <Send className="ml-2 h-4 w-4" />}
            </Button>
          </form>
        </CardContent>
      </Card>
    </main>
  );
}

export default function SubmitNewspaperPage() {
  return (
    <Suspense fallback={<PageLoading />}>
      <SidebarProvider>
        <SidebarNav />
        <SidebarInset>
          <Header />
          <SubmitNewspaperContent />
        </SidebarInset>
      </SidebarProvider>
    </Suspense>
  );
}
