import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import { Header } from '@/components/header';
import { SidebarNav } from '@/components/sidebar-nav';

export default function PrivacyPolicyPage() {
  return (
     <SidebarProvider>
      <SidebarNav />
      <SidebarInset>
        <Header />
        <main className="p-4 sm:p-6 lg:p-8">
            <div className="max-w-4xl mx-auto">
                <h1 className="text-3xl font-bold text-primary mb-4">Privacy Policy</h1>
                <p className="text-sm text-muted-foreground mb-6">Last updated: {new Date().toLocaleDateString()}</p>
                
                <div className="space-y-6 text-foreground">
                    <section>
                        <h2 className="text-xl font-semibold mb-2">Introduction</h2>
                        <p>
                            Welcome to BD News Hub. We are committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our application.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-xl font-semibold mb-2">Information We Collect</h2>
                        <p>
                            We may collect information about you in a variety of ways. The information we may collect via the Application includes:
                        </p>
                        <ul className="list-disc list-inside mt-2 space-y-1">
                            <li><strong>Personal Data:</strong> Personally identifiable information, such as your name, email address, that you voluntarily give to us when you register with the Application.</li>
                            <li><strong>Usage Data:</strong> Information our servers automatically collect when you access the Application, such as your IP address, browser type, and the pages you have viewed.</li>
                        </ul>
                    </section>

                    <section>
                        <h2 className="text-xl font-semibold mb-2">Use of Your Information</h2>
                        <p>
                            Having accurate information about you permits us to provide you with a smooth, efficient, and customized experience. Specifically, we may use information collected about you via the Application to:
                        </p>
                        <ul className="list-disc list-inside mt-2 space-y-1">
                            <li>Create and manage your account.</li>
                            <li>Personalize your user experience.</li>
                            <li>Monitor and analyze usage and trends to improve your experience with the Application.</li>
                        </ul>
                    </section>
                    
                    <section>
                        <h2 className="text-xl font-semibold mb-2">Firebase Integration</h2>
                        <p>
                            Our application uses Firebase services to provide features such as authentication and database management. Firebase is a Google product and has its own privacy policy. We recommend you review the <a href="https://firebase.google.com/policies/analytics" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Firebase Privacy Policy</a> to understand how they handle data. We use Firebase for:
                        </p>
                         <ul className="list-disc list-inside mt-2 space-y-1">
                            <li><strong>Firebase Authentication:</strong> To manage user sign-up and login.</li>
                            <li><strong>Cloud Firestore:</strong> To store user data like profiles, preferences, and saved articles securely.</li>
                        </ul>
                         <p className="mt-2">
                           Your data stored in Firebase is protected by Firestore Security Rules to ensure that only authorized users can access their own data.
                        </p>
                    </section>

                    <section>
                        <h2 className="text-xl font-semibold mb-2">Contact Us</h2>
                        <p>
                            If you have questions or comments about this Privacy Policy, please contact us.
                        </p>
                    </section>
                </div>
            </div>
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
