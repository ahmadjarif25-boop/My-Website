'use client';

import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import { Header } from '@/components/header';
import { SidebarNav } from '@/components/sidebar-nav';
import { Suspense, useEffect, useState } from 'react';
import PageLoading from '../loading';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Trash2, User } from 'lucide-react';
import { Button, buttonVariants } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useFirestore, useUser, updateDocumentNonBlocking, deleteDocumentNonBlocking, initiateDeleteUser } from '@/firebase';
import { useRouter } from 'next/navigation';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { initiateUpdateProfile } from '@/firebase/non-blocking-login';
import { doc } from 'firebase/firestore';
import { MySubmissions } from '@/components/profile/my-submissions';
import { MyFeedback } from '@/components/profile/my-feedback';

const profileSchema = z.object({
  displayName: z.string().min(2, { message: 'Name must be at least 2 characters.' }),
  photoURL: z.string().url({ message: 'Please enter a valid URL.' }).or(z.literal('')),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

export default function ProfilePage() {
  const { user, isUserLoading } = useUser();
  const router = useRouter();
  const firestore = useFirestore();
  const [isEditDialogOpen, setEditDialogOpen] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      displayName: user?.displayName || '',
      photoURL: user?.photoURL || '',
    },
  });

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push('/login');
    }
     if (user) {
      reset({
        displayName: user.displayName || '',
        photoURL: user.photoURL || '',
      });
    }
  }, [user, isUserLoading, router, reset]);
  
  const onProfileSubmit = (data: ProfileFormValues) => {
    if (!user) return;

    initiateUpdateProfile(user, { displayName: data.displayName, photoURL: data.photoURL });

    const userDocRef = doc(firestore, 'users', user.uid);
    updateDocumentNonBlocking(userDocRef, {
      displayName: data.displayName,
      photoUrl: data.photoURL,
    });

    setEditDialogOpen(false);
  };
  
  const handleDeleteAccount = () => {
    if (!user) return;

    const userDocRef = doc(firestore, 'users', user.uid);
    deleteDocumentNonBlocking(userDocRef);

    const adminRoleRef = doc(firestore, 'roles_admin', user.uid);
    deleteDocumentNonBlocking(adminRoleRef);

    initiateDeleteUser(user);

    router.push('/signup');
  };


  if (isUserLoading || !user) {
    return <PageLoading />;
  }

  return (
    <Suspense fallback={<PageLoading />}>
      <SidebarProvider>
        <SidebarNav />
        <SidebarInset>
          <Header />
          <main className="p-4 sm:p-6 lg:p-8 min-h-screen">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-primary">User Profile</h1>
              <p className="text-muted-foreground">Manage your profile and preferences.</p>
            </div>
            
            <div className="grid gap-8 md:grid-cols-3">
                <div className="md:col-span-1">
                    <Card>
                        <CardContent className="flex flex-col items-center gap-4 p-6">
                            <Avatar className="h-24 w-24">
                                <AvatarImage src={user.photoURL || `https://i.pravatar.cc/150?u=${user.uid}`} alt={user.displayName || 'User'} />
                                <AvatarFallback>
                                    <User className="h-12 w-12" />
                                </AvatarFallback>
                            </Avatar>
                            <div className="text-center">
                                <h2 className="text-2xl font-bold">{user.displayName || 'User'}</h2>
                                <p className="text-muted-foreground">{user.email}</p>
                            </div>
                             <Dialog open={isEditDialogOpen} onOpenChange={setEditDialogOpen}>
                              <DialogTrigger asChild>
                                <Button>Edit Profile</Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Edit Profile</DialogTitle>
                                  <DialogDescription>
                                    Make changes to your profile here. Click save when you're done.
                                  </DialogDescription>
                                </DialogHeader>
                                <form onSubmit={handleSubmit(onProfileSubmit)} className="space-y-4 py-4">
                                  <div className="space-y-2">
                                    <Label htmlFor="displayName">Display Name</Label>
                                    <Input id="displayName" {...register('displayName')} />
                                    {errors.displayName && <p className="text-xs text-destructive">{errors.displayName.message}</p>}
                                  </div>
                                  <div className="space-y-2">
                                    <Label htmlFor="photoURL">Photo URL</Label>
                                    <Input id="photoURL" {...register('photoURL')} />
                                     {errors.photoURL && <p className="text-xs text-destructive">{errors.photoURL.message}</p>}
                                  </div>
                                  <DialogFooter>
                                    <Button type="submit">Save Changes</Button>
                                  </DialogFooter>
                                </form>
                              </DialogContent>
                            </Dialog>
                        </CardContent>
                    </Card>
                </div>

                <div className="md:col-span-2 space-y-6">
                    <MySubmissions />
                    <MyFeedback />
                    <Card>
                        <CardHeader>
                            <CardTitle>My Preferences</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-muted-foreground">Followed newspapers and preferred categories will be shown here.</p>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader>
                            <CardTitle>Reading History</CardTitle>
                        </CardHeader>
                        <CardContent>
                         <p className="text-muted-foreground">Your recently read articles will appear here.</p>
                        </CardContent>
                    </Card>
                     <Card>
                        <CardHeader>
                            <CardTitle>Saved Articles</CardTitle>
                        </CardHeader>
                        <CardContent>
                         <p className="text-muted-foreground">Your bookmarked articles will appear here.</p>
                        </CardContent>
                    </Card>
                    <Card className="border-destructive">
                        <CardHeader>
                            <CardTitle className="text-destructive">Danger Zone</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-sm text-muted-foreground mb-4">
                                Deleting your account is a permanent action and cannot be undone. All your data will be permanently removed.
                            </p>
                             <AlertDialog>
                                <AlertDialogTrigger asChild>
                                    <Button variant="destructive">
                                        <Trash2 className="mr-2 h-4 w-4" />
                                        Delete Account
                                    </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                    <AlertDialogHeader>
                                        <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                                        <AlertDialogDescription>
                                            This action cannot be undone. This will permanently delete your
                                            account and remove your data from our servers.
                                        </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                                        <AlertDialogAction onClick={handleDeleteAccount} className={buttonVariants({ variant: "destructive" })}>
                                            Delete
                                        </AlertDialogAction>
                                    </AlertDialogFooter>
                                </AlertDialogContent>
                            </AlertDialog>
                        </CardContent>
                    </Card>
                </div>
            </div>

          </main>
        </SidebarInset>
      </SidebarProvider>
    </Suspense>
  );
}
    