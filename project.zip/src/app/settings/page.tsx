'use client';

import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import { Header } from '@/components/header';
import { SidebarNav } from '@/components/sidebar-nav';
import { Suspense, useEffect } from 'react';
import PageLoading from '../loading';
import { useUser } from '@/firebase';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Settings as SettingsIcon } from 'lucide-react';
import { ThemeToggle } from '@/components/theme-toggle';

export default function SettingsPage() {
  const { user, isUserLoading } = useUser();
  const router = useRouter();

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push('/login');
    }
  }, [user, isUserLoading, router]);

  if (isUserLoading || !user) {
    return <PageLoading />;
  }

  return (
    <Suspense fallback={<PageLoading />}>
      <SidebarProvider>
        <SidebarNav />
        <SidebarInset>
          <Header />
          <main className="p-4 sm:p-6 lg:p-8 min-h-screen">
            <div className="mb-8">
              <h1 className="text-3xl font-bold flex items-center gap-2 text-primary">
                <SettingsIcon className="w-8 h-8 text-primary" />
                Settings
              </h1>
              <p className="text-muted-foreground">Manage your account and application settings.</p>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Appearance</CardTitle>
                <CardDescription>Customize the look and feel of the application.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div>
                    <h3 className="font-medium">Theme</h3>
                    <p className="text-sm text-muted-foreground">
                      Select a light or dark theme for the application.
                    </p>
                  </div>
                  <ThemeToggle />
                </div>
              </CardContent>
            </Card>

          </main>
        </SidebarInset>
      </SidebarProvider>
    </Suspense>
  );
}
