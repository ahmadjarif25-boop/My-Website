'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth, useFirestore, useUser, setDocumentNonBlocking } from '@/firebase';
import { initiateEmailSignUp, initiateUpdateProfile } from '@/firebase/non-blocking-login';
import { zodResolver } from '@hookform/resolvers/zod';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import PageLoading from '../loading';
import { onAuthStateChanged } from 'firebase/auth';
import { Logo } from '@/components/icons';
import { doc, collection, getDocs, query, limit } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { Eye, EyeOff } from 'lucide-react';

const signupSchema = z.object({
  displayName: z.string().min(2, { message: 'Name must be at least 2 characters.' }),
  email: z.string().email({ message: 'Invalid email address.' }),
  password: z.string().min(6, { message: 'Password must be at least 6 characters.' }),
});

type SignupFormValues = z.infer<typeof signupSchema>;

export default function SignupPage() {
  const router = useRouter();
  const auth = useAuth();
  const firestore = useFirestore();
  const { user, isUserLoading } = useUser();
  const { toast } = useToast();
  const [showPassword, setShowPassword] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<SignupFormValues>({
    resolver: zodResolver(signupSchema),
  });

  useEffect(() => {
    if (!isUserLoading && user) {
      router.push('/profile');
    }
  }, [user, isUserLoading, router]);

 const onSubmit = (data: SignupFormValues) => {
    const usersRef = collection(firestore, 'users');
    const q = query(usersRef, limit(1));
    
    getDocs(q).then(querySnapshot => {
        const isFirstUser = querySnapshot.empty;

        const unsubscribe = onAuthStateChanged(auth, (newUser) => {
          if (newUser && newUser.email === data.email && !newUser.displayName) {
            unsubscribe(); // Prevent multiple executions

            const userDocRef = doc(firestore, 'users', newUser.uid);
            const adminRoleRef = doc(firestore, 'roles_admin', newUser.uid);
            
            initiateUpdateProfile(newUser, { displayName: data.displayName });
            
            const userProfileData = {
              id: newUser.uid,
              email: newUser.email,
              displayName: data.displayName,
              photoUrl: newUser.photoURL || '',
              followedSourceIds: [],
              preferredCategories: [],
            };
            
            if (isFirstUser) {
              // Create admin role first, then create user doc to avoid race condition with security rules.
              setDocumentNonBlocking(adminRoleRef, { email: newUser.email, assignedAt: new Date().toISOString() }, { merge: false })
                .then(() => {
                  // Admin role created, now create user.
                  setDocumentNonBlocking(userDocRef, userProfileData, { merge: false });
                  toast({
                    title: 'অ্যাডমিন হিসেবে সফলভাবে নিবন্ধিত হয়েছেন',
                    description: 'আপনাকে অ্যাডমিন প্যানেলে রিডাইরেক্ট করা হচ্ছে।',
                    duration: 5000,
                  });
                });
            } else {
              // Not the first user, just create the user document.
              setDocumentNonBlocking(userDocRef, userProfileData, { merge: false });
              toast({
                title: 'অ্যাডমিন অ্যাকাউন্ট ইতিমধ্যে বিদ্যমান',
                description: 'আপনাকে একজন সাধারণ ব্যবহারকারী হিসেবে নিবন্ধন করা হয়েছে।',
                duration: 5000,
              });
            }
          }
        });

        initiateEmailSignUp(auth, data.email, data.password);
    });
  };
  
  if (isUserLoading || user) {
    return <PageLoading />;
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-sm">
        <CardHeader className="text-center">
          <div className="flex justify-center items-center mb-4">
              <Logo className="h-10 w-10 text-primary" />
            </div>
          <CardTitle className="text-2xl">Create an Account</CardTitle>
          <CardDescription>Enter your information to create an account.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="displayName">Name</Label>
              <Input id="displayName" type="text" placeholder="John Doe" {...register('displayName')} />
              {errors.displayName && <p className="text-xs text-destructive">{errors.displayName.message}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="m@example.com" {...register('email')} />
              {errors.email && <p className="text-xs text-destructive">{errors.email.message}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input id="password" type={showPassword ? 'text' : 'password'} {...register('password')} />
                 <Button 
                    type="button" 
                    variant="ghost" 
                    size="icon" 
                    className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7"
                    onClick={() => setShowPassword(prev => !prev)}
                >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    <span className="sr-only">{showPassword ? 'Hide password' : 'Show password'}</span>
                </Button>
              </div>
              {errors.password && <p className="text-xs text-destructive">{errors.password.message}</p>}
            </div>
            <Button type="submit" className="w-full">
              Sign Up
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex-col gap-4">
          <p className="text-xs text-muted-foreground">
            Already have an account?{' '}
            <Link href="/login" className="font-medium text-primary hover:underline">
              Log in
            </Link>
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}
