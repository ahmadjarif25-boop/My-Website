import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import { Header } from '@/components/header';
import { SidebarNav } from '@/components/sidebar-nav';
import { Suspense } from 'react';
import PageLoading from '../loading';
import { tvChannelsData } from '@/lib/tv-channels-data';
import { TVChannel, tvChannelCategories } from '@/lib/types';
import Image from 'next/image';
import {
  Card,
  CardContent,
  CardFooter,
} from '@/components/ui/card';
import Link from 'next/link';
import { Frown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { TvChannelSearch } from '@/components/tv-channel-search';

type TVChannelsPageProps = {
  searchParams?: {
    q?: string;
    category?: string;
  };
};

export default function TVChannelsPage({ searchParams }: TVChannelsPageProps) {
  const searchQuery = searchParams?.q?.toLowerCase() || '';
  const selectedCategory = searchParams?.category || 'All';

  const filteredChannels = tvChannelsData.filter(channel => {
    const matchesCategory = !selectedCategory || selectedCategory === 'All' || channel.category === selectedCategory;
    const matchesSearch = !searchQuery || channel.name.toLowerCase().includes(searchQuery);

    if (searchQuery) {
      return matchesSearch;
    }

    return matchesCategory;
  });
  
  const groupedChannels = filteredChannels.reduce((acc, channel) => {
    const categoryKey = channel.category;
    if (!acc[categoryKey]) {
      acc[categoryKey] = [];
    }
    acc[categoryKey].push(channel);
    return acc;
  }, {} as Record<string, typeof tvChannelsData>);
  
  const displayedCategories = searchQuery ? Object.keys(groupedChannels) : (selectedCategory !== 'All' ? [selectedCategory] : tvChannelCategories);

  const NoResults = ({ message }: { message: string }) => (
    <div className="flex flex-col items-center justify-center rounded-lg border border-dashed p-12 text-center h-[40vh] bg-card col-span-full">
      <Frown className="mx-auto h-12 w-12 text-muted-foreground" />
      <h3 className="mt-4 text-lg font-semibold">No TV Channels Found</h3>
      <p className="mt-2 text-sm text-muted-foreground">
        {message}
      </p>
    </div>
  )

  const TVChannelCard = ({ channel }: { channel: TVChannel }) => {
    const isClickable = channel.websiteUrl && channel.websiteUrl !== '#';
    const cardContent = (
      <Card className={cn("flex h-full flex-col items-center justify-center overflow-hidden p-4 group", isClickable ? "cursor-pointer" : "cursor-not-allowed opacity-60")}>
        <CardContent className="p-0 flex items-center justify-center flex-grow h-24 w-full">
          <div className="relative h-full w-full">
            <Image
              src={channel.logoUrl}
              alt={`${channel.name} logo`}
              data-ai-hint={channel.imageHint}
              fill
              className="object-contain"
            />
          </div>
        </CardContent>
         <CardFooter className="p-2 pb-0 mt-2 flex-col">
          <p className="text-sm font-semibold text-center text-card-foreground">{channel.name}</p>
        </CardFooter>
      </Card>
    );
  
    if (isClickable) {
      return (
        <Link href={channel.websiteUrl} key={channel.id} target="_blank" rel="noopener noreferrer" className="h-full">
          {cardContent}
        </Link>
      );
    }
  
    return <div className="h-full">{cardContent}</div>;
  };

  return (
    <Suspense fallback={<PageLoading />}>
      <SidebarProvider>
        <SidebarNav />
        <SidebarInset>
          <Header />
          <main className="p-4 sm:p-6 lg:p-8 min-h-screen">
             <div className="mb-8">
               <div className="flex w-full flex-wrap items-center justify-between gap-4">
                 <div className="flex-grow">
                   <h1 className="text-3xl font-bold tracking-tight text-primary">TV Channels</h1>
                 </div>
                 <div className="w-full sm:w-auto">
                   <TvChannelSearch />
                 </div>
               </div>
             </div>
             {filteredChannels.length === 0 && <NoResults message="No TV channels found for the selected criteria." />}
            
            {filteredChannels.length > 0 && displayedCategories.map((category) => {
              const channelsToShow: TVChannel[] = groupedChannels[category] || [];

              if (channelsToShow.length === 0 && category === 'Local' && filteredChannels.length > 0 && !searchQuery) {
                return (
                 <div key={category} className="mb-12">
                   <div className="flex items-center justify-between mb-6 border-b pb-2">
                     <h2 className="text-2xl font-bold tracking-tight text-primary">Local TV Channels</h2>
                   </div>
                   <NoResults message="No local TV channels are available at the moment." />
                 </div>
               );
             }

              if(channelsToShow.length === 0) return null;

              return (
                <div key={category} className="mb-12">
                  <div className="flex items-center justify-between mb-6 border-b pb-2">
                    <h2 className="text-2xl font-bold tracking-tight text-primary">{category} TV Channels</h2>
                  </div>
                    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
                      {channelsToShow.map((channel: TVChannel) => (
                        <TVChannelCard channel={channel} key={channel.id} />
                      ))}
                    </div>
                </div>
              );
            })}
          </main>
        </SidebarInset>
      </SidebarProvider>
    </Suspense>
  );
}
