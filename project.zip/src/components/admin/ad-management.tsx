'use client';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MoreHorizontal, PlusCircle } from "lucide-react";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useCollection, useFirestore, useMemoFirebase, setDocumentNonBlocking, addDocumentNonBlocking, deleteDocumentNonBlocking } from '@/firebase';
import { collection, doc } from "firebase/firestore";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Skeleton } from "../ui/skeleton";
import { Switch } from "../ui/switch";
import { Badge } from "../ui/badge";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";

const adSchema = z.object({
  name: z.string().min(1, "Name is required"),
  type: z.enum(['AdSense', 'Banner']),
  content: z.string().min(1, "Ad Unit ID / Content is required"),
  isActive: z.boolean(),
});

type AdFormValues = z.infer<typeof adSchema>;
type Ad = AdFormValues & { id: string };

export function AdManagement() {
  const { toast } = useToast();
  const firestore = useFirestore();
  
  const [isDialogOpen, setDialogOpen] = useState(false);
  const [editingAd, setEditingAd] = useState<Ad | null>(null);

  const adsQuery = useMemoFirebase(() => collection(firestore, 'ads'), [firestore]);
  const { data: ads, isLoading: adsLoading } = useCollection<Ad>(adsQuery);

  const { register, handleSubmit, control, reset, formState: { errors } } = useForm<AdFormValues>({
    resolver: zodResolver(adSchema),
    defaultValues: {
      name: '',
      type: 'AdSense',
      content: '',
      isActive: true,
    }
  });
  
  useEffect(() => {
    if(editingAd) {
      reset(editingAd);
    } else {
      reset({
        name: '',
        type: 'AdSense',
        content: '',
        isActive: true,
      });
    }
  }, [editingAd, reset]);

  const handleDialogOpen = (ad: Ad | null = null) => {
    setEditingAd(ad);
    setDialogOpen(true);
  }

  const handleDelete = (adId: string) => {
    const adDocRef = doc(firestore, 'ads', adId);
    deleteDocumentNonBlocking(adDocRef);
    toast({
      title: 'Ad Deleted',
      description: 'The ad space has been removed.',
    });
  }
  
  const onSubmit = (data: AdFormValues) => {
    if (editingAd) {
      const adDocRef = doc(firestore, 'ads', editingAd.id);
      setDocumentNonBlocking(adDocRef, data, { merge: true });
      toast({ title: 'Ad Updated', description: `${data.name} has been updated.` });
    } else {
      const adsColRef = collection(firestore, 'ads');
      addDocumentNonBlocking(adsColRef, data);
      toast({ title: 'Ad Space Created', description: `New ad space "${data.name}" has been added.` });
    }
    setDialogOpen(false);
    setEditingAd(null);
  };

  const AdsTable = () => {
    if (adsLoading) {
      return (
        <div className="space-y-2 mt-4">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      );
    }

    if (!ads || ads.length === 0) {
      return (
        <div className="mt-4 p-8 text-center text-muted-foreground border-2 border-dashed rounded-lg">
          <h3 className="text-lg font-semibold">No Ad Spaces Found</h3>
          <p className="mt-1 text-sm">Create a new ad space to get started.</p>
        </div>
      );
    }

    return (
       <div className="rounded-md border mt-4">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {ads.map(ad => (
              <TableRow key={ad.id}>
                <TableCell className="font-medium">{ad.name}</TableCell>
                <TableCell>{ad.type}</TableCell>
                <TableCell>
                  <Badge variant={ad.isActive ? 'default' : 'secondary'}>
                    {ad.isActive ? 'Active' : 'Inactive'}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                   <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleDialogOpen(ad)}>Edit</DropdownMenuItem>
                      <DropdownMenuItem className="text-destructive" onClick={() => handleDelete(ad.id)}>Delete</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
       </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
            <div>
                <CardTitle>Ad Space Management</CardTitle>
                <CardDescription>Control ad networks like AdMob, or display custom banner ads from direct clients.</CardDescription>
            </div>
            <Dialog open={isDialogOpen} onOpenChange={(open) => { setDialogOpen(open); if(!open) setEditingAd(null); }}>
              <DialogTrigger asChild>
                <Button onClick={() => handleDialogOpen()}>
                    <PlusCircle className="w-4 h-4 mr-2" />
                    Create New Ad Space
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                 <form onSubmit={handleSubmit(onSubmit)}>
                    <DialogHeader>
                      <DialogTitle>{editingAd ? 'Edit' : 'Create'} Ad Space</DialogTitle>
                      <DialogDescription>
                        Configure a new space for advertisements in your app. Choose 'Banner' for custom ads.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4 max-h-[65vh] overflow-y-auto pr-6">
                      <div className="space-y-1">
                        <Label htmlFor="name">Ad Space Name</Label>
                        <Input id="name" placeholder="e.g., Homepage Banner" {...register('name')} />
                        {errors.name && <p className="text-xs text-destructive">{errors.name.message}</p>}
                      </div>
                       <div className="space-y-1">
                          <Label htmlFor="type">Ad Type</Label>
                          <Controller
                            control={control}
                            name="type"
                            render={({ field }) => (
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select an ad type" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="AdSense">AdSense/AdMob</SelectItem>
                                        <SelectItem value="Banner">Custom Banner</SelectItem>
                                    </SelectContent>
                                </Select>
                            )}
                          />
                          {errors.type && <p className="text-xs text-destructive">{errors.type.message}</p>}
                      </div>
                       <div className="space-y-1">
                        <Label htmlFor="content">Ad Unit ID / Image URL</Label>
                        <Input id="content" placeholder="ca-app-pub-... or https://example.com/banner.png" {...register('content')} />
                        {errors.content && <p className="text-xs text-destructive">{errors.content.message}</p>}
                      </div>
                      <div className="flex items-center space-x-2">
                         <Controller
                            control={control}
                            name="isActive"
                            render={({ field }) => (
                                <Switch id="isActive" checked={field.value} onCheckedChange={field.onChange} />
                            )}
                          />
                        <Label htmlFor="isActive">Activate Ad Space</Label>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="submit">Save Ad Space</Button>
                    </DialogFooter>
                 </form>
              </DialogContent>
            </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <AdsTable />
      </CardContent>
    </Card>
  );
}
