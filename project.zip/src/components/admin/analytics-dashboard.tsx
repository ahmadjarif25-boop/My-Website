'use client';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Users, Activity, TrendingUp, MousePointerClick } from "lucide-react";
import { useCollection, useFirestore, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, limit } from 'firebase/firestore';
import { Skeleton } from "../ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { Newspaper as NewspaperIcon } from 'lucide-react';

interface NewspaperView {
  id: string;
  newspaperName: string;
  viewCount: number;
  logoUrl: string;
}

export function AnalyticsDashboard() {
  const firestore = useFirestore();
  const usersQuery = useMemoFirebase(() => collection(firestore, 'users'), [firestore]);
  const { data: users, isLoading: usersLoading } = useCollection(usersQuery);

  const topNewspapersQuery = useMemoFirebase(() => {
    if (!firestore) return null;
    return query(
      collection(firestore, 'newspaper_view_counts'),
      orderBy('viewCount', 'desc'),
      limit(5)
    );
  }, [firestore]);

  const { data: topNewspapers, isLoading: topNewspapersLoading } = useCollection<NewspaperView>(topNewspapersQuery);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Analytics Dashboard</CardTitle>
        <CardDescription>Track app usage and content popularity.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
         <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Users
              </CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {usersLoading ? (
                <Skeleton className="h-8 w-20" />
              ) : (
                <div className="text-2xl font-bold">{users?.length ?? 0}</div>
              )}
              <p className="text-xs text-muted-foreground">
                Total registered users in the app
              </p>
            </CardContent>
          </Card>
           <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Real-time Active Users
              </CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">0</div>
              <p className="text-xs text-muted-foreground">
                (placeholder, requires real-time integration)
              </p>
            </CardContent>
          </Card>
           <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average CTR</CardTitle>
              <MousePointerClick className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">0%</div>
              <p className="text-xs text-muted-foreground">
                (placeholder, requires click tracking)
              </p>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><TrendingUp className="h-5 w-5" /> Top Newspapers</CardTitle>
            <CardDescription>Ranking of the most read newspapers by users.</CardDescription>
          </CardHeader>
          <CardContent>
            {topNewspapersLoading ? (
                <div className="rounded-md border">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Rank</TableHead>
                                <TableHead>Newspaper</TableHead>
                                <TableHead className="text-right">Views</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {[...Array(5)].map((_, i) => (
                                <TableRow key={i}>
                                    <TableCell><Skeleton className="h-4 w-4" /></TableCell>
                                    <TableCell>
                                      <div className="flex items-center gap-3">
                                        <Skeleton className="h-8 w-8 rounded-full" />
                                        <Skeleton className="h-4 w-32" />
                                      </div>
                                    </TableCell>
                                    <TableCell className="text-right"><Skeleton className="h-4 w-12 ml-auto" /></TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
            ) : (
             <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Rank</TableHead>
                    <TableHead>Newspaper</TableHead>
                    <TableHead className="text-right">Views</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topNewspapers && topNewspapers.length > 0 ? (
                    topNewspapers.map((paper, index) => (
                      <TableRow key={paper.id}>
                        <TableCell className="font-medium">{index + 1}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-3">
                              <Avatar className="h-8 w-8 border">
                                  <AvatarImage src={paper.logoUrl} alt={paper.newspaperName} />
                                  <AvatarFallback><NewspaperIcon className="h-4 w-4" /></AvatarFallback>
                              </Avatar>
                              <span>{paper.newspaperName}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">{paper.viewCount.toLocaleString()}</TableCell>
                      </TableRow>
                    ))
                  ) : (
                     <TableRow>
                        <TableCell colSpan={3} className="h-24 text-center">
                            No newspaper view data available yet.
                        </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
             </div>
            )}
          </CardContent>
        </Card>

        <div className="p-8 text-center text-muted-foreground border-2 border-dashed rounded-lg">
            Article Click-Through Rate (CTR) Chart Placeholder
        </div>
      </CardContent>
    </Card>
  );
}
