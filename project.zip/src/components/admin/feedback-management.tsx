'use client';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useCollection, useFirestore, useMemoFirebase, useUser, updateDocumentNonBlocking } from '@/firebase';
import { collection, query, orderBy, Timestamp, doc, serverTimestamp } from "firebase/firestore";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Skeleton } from "../ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { formatDistanceToNow } from 'date-fns';
import { MessageSquare, User, MoreHorizontal, Reply as ReplyIcon } from "lucide-react";
import type { Feedback } from "@/lib/types";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Textarea } from "../ui/textarea";
import { Label } from "../ui/label";

const replySchema = z.object({
  reply: z.string().min(1, "Reply cannot be empty."),
});
type ReplyFormValues = z.infer<typeof replySchema>;

export function FeedbackManagement() {
  const firestore = useFirestore();
  const { user: adminUser } = useUser();
  const { toast } = useToast();
  
  const [isReplyDialogOpen, setReplyDialogOpen] = useState(false);
  const [selectedFeedback, setSelectedFeedback] = useState<Feedback | null>(null);

  const feedbackQuery = useMemoFirebase(() => query(collection(firestore, 'feedbacks'), orderBy('submittedAt', 'desc')), [firestore]);
  const { data: feedbacks, isLoading } = useCollection<Feedback>(feedbackQuery);

  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm<ReplyFormValues>({
    resolver: zodResolver(replySchema),
  });

  const handleReplyOpen = (feedback: Feedback) => {
    setSelectedFeedback(feedback);
    reset({ reply: feedback.adminReply || '' });
    setReplyDialogOpen(true);
  };

  const onReplySubmit = async (data: ReplyFormValues) => {
    if (!selectedFeedback || !adminUser) return;

    const replyData = {
      adminReply: data.reply,
      repliedAt: serverTimestamp(),
      repliedBy: adminUser.displayName || 'Admin',
    };

    // Update admin collection
    const adminFeedbackRef = doc(firestore, 'feedbacks', selectedFeedback.id);
    await updateDocumentNonBlocking(adminFeedbackRef, replyData);

    // Update user subcollection if the user is not anonymous
    if (selectedFeedback.userId) {
      const userFeedbackRef = doc(firestore, 'users', selectedFeedback.userId, 'feedbacks', selectedFeedback.id);
      await updateDocumentNonBlocking(userFeedbackRef, replyData);
    }
    
    toast({ title: 'Reply Sent Successfully!', description: 'The user will be able to see your reply on their profile page.' });
    setReplyDialogOpen(false);
    setSelectedFeedback(null);
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>User Feedback</CardTitle>
          <CardDescription>Review feedback submitted by your application users and reply to them.</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2 mt-4">
              {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}
            </div>
          ) : !feedbacks || feedbacks.length === 0 ? (
            <div className="mt-4 p-8 text-center text-muted-foreground border-2 border-dashed rounded-lg">
              <MessageSquare className="mx-auto h-12 w-12" />
              <h3 className="mt-4 text-lg font-semibold">No Feedback Yet</h3>
              <p className="mt-1 text-sm">When users submit feedback, it will appear here.</p>
            </div>
          ) : (
            <div className="rounded-md border mt-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Submitted By</TableHead>
                    <TableHead>Feedback</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {feedbacks.map(fb => (
                    <TableRow key={fb.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-9 w-9 border">
                            <AvatarImage src={''} />
                            <AvatarFallback><User className="h-5 w-5"/></AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">{fb.name || 'Anonymous'}</div>
                            <div className="text-xs text-muted-foreground">{fb.email || `User ID: ${fb.userId?.substring(0, 8) || 'N/A'}`}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="max-w-xs whitespace-pre-wrap">{fb.feedback}</TableCell>
                      <TableCell>
                        <Badge variant={fb.adminReply ? 'default' : 'secondary'}>
                          {fb.adminReply ? 'Replied' : 'Pending'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right text-xs text-muted-foreground">
                        {fb.submittedAt instanceof Timestamp ? formatDistanceToNow(fb.submittedAt.toDate(), { addSuffix: true }) : 'N/A'}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon"><MoreHorizontal className="h-4 w-4" /></Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleReplyOpen(fb)} disabled={!fb.userId}>
                              <ReplyIcon className="mr-2 h-4 w-4" />
                              <span>{fb.adminReply ? 'View/Edit Reply' : 'Reply'}</span>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isReplyDialogOpen} onOpenChange={setReplyDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Reply to Feedback</DialogTitle>
            <DialogDescription>
              Your reply will be visible to the user on their profile page.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="p-4 bg-muted/50 rounded-md border">
              <p className="text-sm font-semibold">{selectedFeedback?.name || 'Anonymous'} said:</p>
              <p className="text-sm text-muted-foreground italic mt-1">"{selectedFeedback?.feedback}"</p>
            </div>
            <form onSubmit={handleSubmit(onReplySubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="reply">Your Reply</Label>
                <Textarea id="reply" placeholder="Write an encouraging reply..." {...register('reply')} rows={5}/>
                {errors.reply && <p className="text-sm text-destructive">{errors.reply.message}</p>}
              </div>
              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => setReplyDialogOpen(false)}>Cancel</Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? 'Sending...' : 'Send Reply'}
                </Button>
              </DialogFooter>
            </form>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
