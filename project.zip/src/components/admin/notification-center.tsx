'use client';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export function NotificationCenter() {
  const { toast } = useToast();
  const [message, setMessage] = useState('');

  const handleSend = () => {
    if (!message.trim()) {
      toast({
        variant: 'destructive',
        title: 'Empty Message',
        description: 'Please enter a notification message.',
      });
      return;
    }
    // In a real app, you would have a backend service to send push notifications.
    // For this prototype, we'll just simulate it with a toast.
    console.log('Sending notification:', message);
    toast({
      title: 'Notification Sent',
      description: `Message: "${message}" has been queued for delivery.`,
    });
    setMessage('');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Push Notification Center</CardTitle>
        <CardDescription>Send custom notifications to all your app users.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid w-full gap-2">
            <Label htmlFor="notification-message">Notification Message</Label>
            <Textarea id="notification-message" placeholder="Type your notification message here..." value={message} onChange={(e) => setMessage(e.target.value)} />
            <Button onClick={handleSend}>
                <Send className="w-4 h-4 mr-2"/>
                Send Notification
            </Button>
        </div>
        <div className="mt-6">
            <h4 className="font-semibold mb-2">Notification History</h4>
             <div className="mt-4 p-8 text-center text-muted-foreground border-2 border-dashed rounded-lg">
                Notification History Placeholder
            </div>
        </div>
      </CardContent>
    </Card>
  );
}
