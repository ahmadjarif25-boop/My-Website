'use client';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PlusCircle } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Textarea } from "../ui/textarea";

export function QuizCreator() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();

  const handleCreateQuiz = () => {
    toast({
      title: 'Quiz/Poll Created',
      description: 'The new quiz/poll has been saved and is ready to be published.',
    });
    setOpen(false);
  }

  return (
    <Card>
      <CardHeader>
         <div className="flex items-center justify-between">
            <div>
                <CardTitle>Quiz & Poll Creator</CardTitle>
                <CardDescription>Create daily quizzes and polls to engage users.</CardDescription>
            </div>
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button>
                    <PlusCircle className="w-4 h-4 mr-2" />
                    Create New Quiz/Poll
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>Create New Quiz</DialogTitle>
                  <DialogDescription>
                    Fill in the details below to create a new quiz or poll.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4 max-h-[65vh] overflow-y-auto pr-6">
                  <div className="space-y-2">
                    <Label htmlFor="quiz-title">Title</Label>
                    <Input id="quiz-title" placeholder="e.g., Weekly Sports Quiz" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="quiz-question">Question</Label>
                    <Textarea id="quiz-question" placeholder="What is the capital of Bangladesh?" />
                  </div>
                   <div className="space-y-2">
                    <Label>Options (one per line)</Label>
                    <Textarea placeholder="Dhaka\nChattogram\nSylhet\nKhulna" />
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit" onClick={handleCreateQuiz}>Create Quiz</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground">This section will provide a complete interface to create questions, set answers, and publish quizzes or polls to the app.</p>
        <div className="mt-4 p-8 text-center text-muted-foreground border-2 border-dashed rounded-lg">
            Quiz & Poll Creation UI Placeholder
        </div>
      </CardContent>
    </Card>
  );
}
