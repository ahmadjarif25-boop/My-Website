'use client';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MoreHorizontal, PlusCircle, Newspaper, Image as ImageIcon } from "lucide-react";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useCollection, useFirestore, useMemoFirebase, deleteDocumentNonBlocking, uploadFileAndGetURL, setDocumentNonBlocking, addDocumentNonBlocking, useStorage } from '@/firebase';
import { collection, doc } from "firebase/firestore";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Skeleton } from "../ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { Switch } from "../ui/switch";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { newspaperCategories } from "@/lib/types";
import { districtsData } from "@/lib/districts-data";
import { compressImage } from "@/lib/utils";
import { Progress } from "../ui/progress";

const sourceSchema = z.object({
  name: z.string().min(1, "Name is required"),
  nameBn: z.string().optional(),
  logoFile: z.any().optional(),
  logoUrl: z.string().url("Must be a valid URL.").optional().or(z.literal('')),
  rssLink: z.string().url("Must be a valid URL"),
  imageHint: z.string().optional(),
  category: z.enum(newspaperCategories),
  district: z.string().optional(),
  districtBn: z.string().optional(),
  isActive: z.boolean(),
}).refine(data => !!data.logoUrl || (data.logoFile && data.logoFile.length > 0), {
    message: "Please provide a logo URL or upload a logo file.",
    path: ["logoUrl"],
});

type SourceFormValues = z.infer<typeof sourceSchema>;

interface Source extends Omit<z.infer<typeof sourceSchema>, 'logoFile' | 'logoUrl'> {
  id: string;
  logoUrl: string;
}

export function SourceManagement() {
  const { toast } = useToast();
  const firestore = useFirestore();
  const storage = useStorage();
  
  const [isDialogOpen, setDialogOpen] = useState(false);
  const [editingSource, setEditingSource] = useState<Source | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);

  const sourcesQuery = useMemoFirebase(() => collection(firestore, 'sources'), [firestore]);
  const { data: sources, isLoading: sourcesLoading } = useCollection<Source>(sourcesQuery);

  const { register, handleSubmit, control, reset, watch, setValue, formState: { errors } } = useForm<SourceFormValues>({
    resolver: zodResolver(sourceSchema),
    defaultValues: {
      name: '',
      nameBn: '',
      logoFile: null,
      logoUrl: '',
      rssLink: '',
      imageHint: '',
      category: 'National',
      district: '',
      districtBn: '',
      isActive: true,
    }
  });

  const category = watch('category');
  const logoFile = watch('logoFile');
  const logoUrl = watch('logoUrl');

   useEffect(() => {
    const file = logoFile?.[0];
    if (file instanceof File) {
      const newPreviewUrl = URL.createObjectURL(file);
      setLogoPreview(newPreviewUrl);
      return () => URL.revokeObjectURL(newPreviewUrl);
    } else if (logoUrl) {
      setLogoPreview(logoUrl);
    } else if (editingSource?.logoUrl) {
      setLogoPreview(editingSource.logoUrl)
    }
    else {
      setLogoPreview(null);
    }
  }, [logoFile, logoUrl, editingSource]);

  
  useEffect(() => {
    if(editingSource) {
      reset({
        name: editingSource.name,
        nameBn: editingSource.nameBn || '',
        logoFile: null,
        logoUrl: editingSource.logoUrl,
        rssLink: editingSource.rssLink,
        imageHint: editingSource.imageHint || '',
        category: editingSource.category,
        district: editingSource.district || '',
        districtBn: editingSource.districtBn || '',
        isActive: editingSource.isActive,
      });
      setLogoPreview(editingSource.logoUrl);
    } else {
      reset({
        name: '',
        nameBn: '',
        logoFile: null,
        logoUrl: '',
        rssLink: '',
        imageHint: '',
        category: 'National',
        district: '',
        districtBn: '',
        isActive: true,
      });
      setLogoPreview(null);
    }
  }, [editingSource, reset]);

  const handleDialogOpen = (source: Source | null = null) => {
    setEditingSource(source);
    setDialogOpen(true);
  }

  const handleDelete = (sourceId: string) => {
    const sourceDocRef = doc(firestore, 'sources', sourceId);
    deleteDocumentNonBlocking(sourceDocRef);
    toast({
      title: 'Source Deleted',
      description: 'The news source has been removed.',
    });
  }
  
  const onSubmit = async (data: SourceFormValues) => {
    setIsSubmitting(true);
    setUploadProgress(null);

    try {
        let finalLogoUrl = data.logoUrl || editingSource?.logoUrl || '';
        const logoFile = data.logoFile?.[0];

        if (logoFile instanceof File) {
            const compressedFile = await compressImage(logoFile, { maxWidth: 512, quality: 0.8 });
            const uploadPath = `logos/${Date.now()}_${compressedFile.name}`;
            finalLogoUrl = await uploadFileAndGetURL(storage, compressedFile, uploadPath, setUploadProgress);
            setUploadProgress(100);
        }
        
        if (!finalLogoUrl) {
            toast({
                variant: "destructive",
                title: "Logo Required",
                description: "Please provide a logo by either uploading a file or providing a URL.",
            });
            setIsSubmitting(false);
            return;
        }
        
        const sourceData = {
            name: data.name,
            nameBn: data.nameBn,
            logoUrl: finalLogoUrl,
            rssLink: data.rssLink,
            imageHint: data.imageHint,
            category: data.category,
            district: data.district,
            districtBn: data.districtBn,
            isActive: data.isActive,
        };

        if (editingSource) {
            const sourceDocRef = doc(firestore, 'sources', editingSource.id);
            await setDocumentNonBlocking(sourceDocRef, sourceData, { merge: true });
            toast({ title: 'Source Updated', description: `${data.name} has been updated.` });
        } else {
            const sourcesColRef = collection(firestore, 'sources');
            await addDocumentNonBlocking(sourcesColRef, sourceData);
            toast({ title: 'Source Added', description: `${data.name} has been added.` });
        }

        setDialogOpen(false);
        setEditingSource(null);
    } catch (error: any) {
        console.error("Source submission failed:", error);
        toast({
            variant: "destructive",
            title: "Operation Failed",
            description: error.message || "Could not save the source. Please try again.",
        });
    } finally {
        setIsSubmitting(false);
        setUploadProgress(null);
    }
  };


  const handleDistrictChange = (districtName: string) => {
    const selectedDistrict = districtsData.find(d => d.name === districtName);
    if (selectedDistrict) {
      setValue('district', selectedDistrict.name);
      setValue('districtBn', selectedDistrict.nameBn);
    }
  }
  
  const SourcesTable = () => {
    if (sourcesLoading) {
      return (
        <div className="space-y-2 mt-4">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      )
    }

    if (!sources || sources.length === 0) {
      return (
        <div className="mt-4 p-8 text-center text-muted-foreground border-2 border-dashed rounded-lg">
          <Newspaper className="mx-auto h-12 w-12" />
          <h3 className="mt-4 text-lg font-semibold">No Sources Found</h3>
          <p className="mt-1 text-sm">Add a new source to get started.</p>
        </div>
      );
    }

    return (
       <div className="rounded-md border mt-4">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sources.map(source => (
              <TableRow key={source.id}>
                <TableCell>
                  <div className="flex items-center gap-4">
                    <Avatar className="h-10 w-10 border">
                      <AvatarImage src={source.logoUrl} alt={source.name} />
                      <AvatarFallback><Newspaper/></AvatarFallback>
                    </Avatar>
                    <span className="font-medium">{source.name}</span>
                  </div>
                </TableCell>
                <TableCell>{source.category}</TableCell>
                <TableCell>{source.isActive ? 'Active' : 'Inactive'}</TableCell>
                <TableCell className="text-right">
                   <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleDialogOpen(source)}>Edit</DropdownMenuItem>
                      <DropdownMenuItem className="text-destructive" onClick={() => handleDelete(source.id)}>Delete</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
       </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
            <div>
                <CardTitle>Newspaper & Source Management</CardTitle>
                <CardDescription>Add, update, or remove newspaper sources. You can also manage logos by uploading an image.</CardDescription>
            </div>
            <Dialog open={isDialogOpen} onOpenChange={(open) => { setDialogOpen(open); if(!open) setEditingSource(null); }}>
              <DialogTrigger asChild>
                <Button onClick={() => handleDialogOpen()}>
                    <PlusCircle className="w-4 h-4 mr-2" />
                    Add New Source
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                 <form onSubmit={handleSubmit(onSubmit)}>
                    <DialogHeader>
                      <DialogTitle>{editingSource ? 'Edit' : 'Add'} Source</DialogTitle>
                      <DialogDescription>
                        Fill in the details for the news source. A live preview of the logo will be shown.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4 max-h-[70vh] overflow-y-auto pr-4">
                      <div className="space-y-1">
                        <Label htmlFor="name">Name</Label>
                        <Input id="name" {...register('name')} />
                        {errors.name && <p className="text-xs text-destructive">{errors.name.message}</p>}
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="nameBn">Name (Bengali)</Label>
                        <Input id="nameBn" {...register('nameBn')} />
                      </div>
                      
                      <Card className="p-4 bg-muted/50">
                        <CardHeader className="p-0 pb-4">
                          <CardTitle className="text-base">Source Logo</CardTitle>
                          <CardDescription className="text-xs">Upload a file or provide a direct image URL. A preview will be shown below.</CardDescription>
                        </CardHeader>
                        <CardContent className="p-0">
                          <div className="grid grid-cols-2 gap-4 items-start">
                            <div className="space-y-4">
                               <div className="space-y-1">
                                <Label htmlFor="logoFile" className="text-xs">Upload from device</Label>
                                <Input id="logoFile" type="file" accept="image/*" {...register('logoFile')} disabled={isSubmitting} />
                                {uploadProgress !== null && uploadProgress < 100 && (
                                    <div className="mt-2">
                                        <Progress value={uploadProgress} className="w-full" />
                                        <p className="text-xs text-muted-foreground mt-1 text-center">{Math.round(uploadProgress)}% Uploaded</p>
                                    </div>
                                )}
                              </div>
                              <div className="relative">
                                  <div className="absolute inset-0 flex items-center"><span className="w-full border-t" /></div>
                                  <div className="relative flex justify-center text-xs uppercase"><span className="bg-muted/50 px-2 text-muted-foreground">Or</span></div>
                              </div>
                              <div className="space-y-1">
                                <Label htmlFor="logoUrl" className="text-xs">Provide image URL</Label>
                                <Input id="logoUrl" placeholder="https://.../logo.png" {...register('logoUrl')} />
                              </div>
                            </div>
                            <div className="flex justify-center items-center h-32 rounded-md border-2 border-dashed bg-background">
                              {logoPreview ? (
                                  <img src={logoPreview} alt="Logo Preview" className="max-h-full max-w-full object-contain p-2" />
                                ) : (
                                  <div className="text-center text-muted-foreground">
                                    <ImageIcon className="mx-auto h-8 w-8" />
                                    <p className="mt-1 text-xs">Logo Preview</p>
                                  </div>
                                )}
                            </div>
                          </div>
                          {(errors.logoFile || errors.logoUrl) && !logoPreview && <p className="text-xs text-destructive mt-2">Please upload a file or provide a valid URL.</p>}
                        </CardContent>
                      </Card>

                       <div className="space-y-1">
                        <Label htmlFor="rssLink">Website/RSS URL</Label>
                        <Input id="rssLink" {...register('rssLink')} />
                        {errors.rssLink && <p className="text-xs text-destructive">{errors.rssLink.message}</p>}
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="imageHint">Image Hint (Optional)</Label>
                        <Input id="imageHint" {...register('imageHint')} placeholder="e.g., Prothom Alo logo" />
                      </div>
                      <div className="space-y-1">
                          <Label htmlFor="category">Category</Label>
                          <Controller
                            control={control}
                            name="category"
                            render={({ field }) => (
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select a category" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {newspaperCategories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                                    </SelectContent>
                                </Select>
                            )}
                          />
                          {errors.category && <p className="text-xs text-destructive">{errors.category.message}</p>}
                      </div>
                      {category === 'Local' && (
                        <>
                          <div className="space-y-1">
                            <Label htmlFor="district">District</Label>
                            <Controller
                              control={control}
                              name="district"
                              render={({ field }) => (
                                  <Select onValueChange={(value) => {
                                      field.onChange(value);
                                      handleDistrictChange(value);
                                    }} 
                                    defaultValue={field.value}>
                                      <SelectTrigger>
                                          <SelectValue placeholder="Select a district" />
                                      </SelectTrigger>
                                      <SelectContent>
                                          {districtsData.map(d => <SelectItem key={d.name} value={d.name}>{d.name} ({d.nameBn})</SelectItem>)}
                                      </SelectContent>
                                  </Select>
                              )}
                            />
                          </div>
                          <div className="space-y-1">
                            <Label htmlFor="districtBn">District (Bengali)</Label>
                            <Input id="districtBn" {...register('districtBn')} readOnly />
                          </div>
                        </>
                      )}
                      <div className="flex items-center space-x-2">
                         <Controller
                            control={control}
                            name="isActive"
                            render={({ field }) => (
                                <Switch id="isActive" checked={field.value} onCheckedChange={field.onChange} />
                            )}
                          />
                        <Label htmlFor="isActive">Is Active</Label>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="submit" disabled={isSubmitting}>
                        {isSubmitting ? (editingSource ? 'Updating...' : 'Adding...') : (editingSource ? 'Update Source' : 'Add Source')}
                      </Button>
                    </DialogFooter>
                 </form>
              </DialogContent>
            </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <SourcesTable />
      </CardContent>
    </Card>
  );
}
