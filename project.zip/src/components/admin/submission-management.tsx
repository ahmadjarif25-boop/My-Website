'use client';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MoreHorizontal, ExternalLink, Check, X } from "lucide-react";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useCollection, useFirestore, useMemoFirebase, setDocumentNonBlocking, addDocumentNonBlocking } from '@/firebase';
import { collection, doc, query, where, Timestamp } from "firebase/firestore";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Skeleton } from "../ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { Badge } from "../ui/badge";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { newspaperCategories, SubmittedSource } from "@/lib/types";
import { Textarea } from "../ui/textarea";
import { districtsData } from "@/lib/districts-data";
import { formatDistanceToNow } from 'date-fns';
import { Switch } from "@/components/ui/switch";

const approveSchema = z.object({
  name: z.string().min(1, "Name is required"),
  nameBn: z.string().optional(),
  logoUrl: z.string().url("Must be a valid URL."),
  rssLink: z.string().url("Must be a valid URL"),
  category: z.enum(newspaperCategories),
  district: z.string().optional(),
  districtBn: z.string().optional(),
  isActive: z.boolean(),
});
type ApproveFormValues = z.infer<typeof approveSchema>;

const rejectSchema = z.object({
    rejectionReason: z.string().min(10, 'Please provide a reason for rejection (min 10 characters).'),
});
type RejectFormValues = z.infer<typeof rejectSchema>;


export function SubmissionManagement() {
  const { toast } = useToast();
  const firestore = useFirestore();
  
  const [isApproveOpen, setApproveOpen] = useState(false);
  const [isRejectOpen, setRejectOpen] = useState(false);
  const [selectedSubmission, setSelectedSubmission] = useState<SubmittedSource | null>(null);

  const submissionsQuery = useMemoFirebase(() => query(collection(firestore, 'submitted_sources'), where('status', '==', 'pending')), [firestore]);
  const { data: submissions, isLoading } = useCollection<SubmittedSource>(submissionsQuery);

  const approveForm = useForm<ApproveFormValues>({ resolver: zodResolver(approveSchema) });
  const rejectForm = useForm<RejectFormValues>({ resolver: zodResolver(rejectSchema) });

  useEffect(() => {
    if (selectedSubmission) {
      approveForm.reset({
        name: selectedSubmission.mediaName,
        nameBn: '',
        logoUrl: selectedSubmission.logoUrl,
        rssLink: selectedSubmission.mediaLink,
        category: selectedSubmission.sourceCategory,
        district: selectedSubmission.district || '',
        districtBn: selectedSubmission.districtBn || '',
        isActive: true,
      });
    }
  }, [selectedSubmission, approveForm]);
  
  const handleApproveOpen = (submission: SubmittedSource) => {
    setSelectedSubmission(submission);
    setApproveOpen(true);
  }

  const handleRejectOpen = (submission: SubmittedSource) => {
    setSelectedSubmission(submission);
    rejectForm.reset();
    setRejectOpen(true);
  }

  const onApproveSubmit = async (data: ApproveFormValues) => {
    if (!selectedSubmission) return;

    const sourceData = {
        ...data,
        imageHint: `${data.name} logo`, // Auto-generate image hint
    };

    // 1. Add to main 'sources' collection
    addDocumentNonBlocking(collection(firestore, 'sources'), sourceData);

    // 2. Update status in 'submitted_sources'
    const submissionRef = doc(firestore, 'submitted_sources', selectedSubmission.id);
    setDocumentNonBlocking(submissionRef, { status: 'approved' }, { merge: true });
    
    // 3. Update status in user's subcollection
    const userSubmissionRef = doc(firestore, 'users', selectedSubmission.userId, 'submissions', selectedSubmission.id);
    setDocumentNonBlocking(userSubmissionRef, { status: 'approved' }, { merge: true });

    toast({ title: 'Submission Approved', description: `${data.name} has been added to the sources.` });
    setApproveOpen(false);
  };

  const onRejectSubmit = async (data: RejectFormValues) => {
    if (!selectedSubmission) return;
    
    const { rejectionReason } = data;

    // 1. Update status and reason in 'submitted_sources'
    const submissionRef = doc(firestore, 'submitted_sources', selectedSubmission.id);
    setDocumentNonBlocking(submissionRef, { status: 'rejected', rejectionReason }, { merge: true });

    // 2. Update status and reason in user's subcollection
    const userSubmissionRef = doc(firestore, 'users', selectedSubmission.userId, 'submissions', selectedSubmission.id);
    setDocumentNonBlocking(userSubmissionRef, { status: 'rejected', rejectionReason }, { merge: true });

    toast({ title: 'Submission Rejected', variant: 'destructive' });
    setRejectOpen(false);
  }

  const handleDistrictChange = (districtName: string) => {
    const selectedDistrict = districtsData.find(d => d.name === districtName);
    if (selectedDistrict) {
      approveForm.setValue('district', selectedDistrict.name);
      approveForm.setValue('districtBn', selectedDistrict.nameBn);
    }
  }

  const category = approveForm.watch('category');

  return (
    <Card>
      <CardHeader>
        <CardTitle>Newspaper Submissions</CardTitle>
        <CardDescription>Review and manage user-submitted newspaper sources. Approved sources will be added to the main list.</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2 mt-4">
            {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}
          </div>
        ) : !submissions || submissions.length === 0 ? (
          <div className="mt-4 p-8 text-center text-muted-foreground border-2 border-dashed rounded-lg">
            <h3 className="text-lg font-semibold">No Pending Submissions</h3>
            <p className="mt-1 text-sm">All user submissions have been reviewed.</p>
          </div>
        ) : (
          <div className="rounded-md border mt-4">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Source</TableHead>
                  <TableHead>Submitted By</TableHead>
                  <TableHead>Submitted At</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {submissions.map(sub => (
                  <TableRow key={sub.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="h-9 w-9 border"><AvatarImage src={sub.logoUrl} /></Avatar>
                        <div>
                          <div className="font-medium">{sub.mediaName}</div>
                          <Badge variant="outline">{sub.sourceCategory}</Badge>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>{sub.userDisplayName}</div>
                      <div className="text-xs text-muted-foreground">{sub.userEmail}</div>
                    </TableCell>
                    <TableCell>
                      {sub.submittedAt instanceof Timestamp ? formatDistanceToNow(sub.submittedAt.toDate(), { addSuffix: true }) : 'N/A'}
                    </TableCell>
                    <TableCell className="text-right">
                       <DropdownMenu>
                        <DropdownMenuTrigger asChild><Button variant="ghost" size="icon"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild><a href={sub.mediaLink} target="_blank" rel="noopener noreferrer" className="flex items-center">
                            <ExternalLink className="mr-2 h-4 w-4" /> Preview
                          </a></DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleApproveOpen(sub)}><Check className="mr-2 h-4 w-4 text-green-500" />Approve</DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleRejectOpen(sub)} className="text-destructive"><X className="mr-2 h-4 w-4" />Reject</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
        
        {/* Approve Dialog */}
        <Dialog open={isApproveOpen} onOpenChange={setApproveOpen}>
            <DialogContent className="sm:max-w-md">
                <DialogHeader><DialogTitle>Approve Submission</DialogTitle><DialogDescription>Review and edit the details before adding to sources.</DialogDescription></DialogHeader>
                <form onSubmit={approveForm.handleSubmit(onApproveSubmit)} className="space-y-4 max-h-[70vh] overflow-y-auto pr-4">
                     {/* Form fields from SourceManagement, adapted */}
                      <div className="space-y-1">
                        <Label htmlFor="name">Name</Label>
                        <Input {...approveForm.register('name')} />
                        {approveForm.formState.errors.name && <p className="text-xs text-destructive">{approveForm.formState.errors.name.message}</p>}
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="nameBn">Name (Bengali)</Label>
                        <Input {...approveForm.register('nameBn')} />
                      </div>
                       <div className="space-y-1">
                        <Label htmlFor="logoUrl">লোগোর সরাসরি ইমেজ লিংক (Logo's Direct Image URL)</Label>
                        <Input {...approveForm.register('logoUrl')} />
                        <p className="text-xs text-muted-foreground pt-1">
                          প্রয়োজনে লিংকটি এডিট করে ছবির সঠিক ও সরাসরি লিংক (.png, .jpg) দিন।
                        </p>
                        {approveForm.formState.errors.logoUrl && <p className="text-xs text-destructive">{approveForm.formState.errors.logoUrl.message}</p>}
                      </div>
                       <div className="space-y-1">
                        <Label htmlFor="rssLink">Website/RSS URL</Label>
                        <Input {...approveForm.register('rssLink')} />
                        {approveForm.formState.errors.rssLink && <p className="text-xs text-destructive">{approveForm.formState.errors.rssLink.message}</p>}
                      </div>
                      <div className="space-y-1">
                          <Label htmlFor="category">Category</Label>
                          <Controller
                            control={approveForm.control}
                            name="category"
                            render={({ field }) => (
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <SelectTrigger><SelectValue placeholder="Select a category" /></SelectTrigger>
                                    <SelectContent>{newspaperCategories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}</SelectContent>
                                </Select>
                            )}
                          />
                      </div>
                      {category === 'Local' && (
                        <>
                          <div className="space-y-1">
                            <Label htmlFor="district">District</Label>
                            <Controller
                              control={approveForm.control}
                              name="district"
                              render={({ field }) => (
                                <Select onValueChange={(value) => { field.onChange(value); handleDistrictChange(value); }} defaultValue={field.value}>
                                  <SelectTrigger><SelectValue placeholder="Select a district" /></SelectTrigger>
                                  <SelectContent>{districtsData.map(d => <SelectItem key={d.name} value={d.name}>{d.name} ({d.nameBn})</SelectItem>)}</SelectContent>
                                </Select>
                              )}
                            />
                          </div>
                          <div className="space-y-1">
                            <Label htmlFor="districtBn">District (Bengali)</Label>
                            <Input {...approveForm.register('districtBn')} readOnly />
                          </div>
                        </>
                      )}
                      <div className="flex items-center space-x-2">
                         <Controller control={approveForm.control} name="isActive" render={({ field }) => (<Switch id="isActive" checked={field.value} onCheckedChange={field.onChange} />)} />
                         <Label htmlFor="isActive">Set as Active</Label>
                      </div>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => setApproveOpen(false)}>Cancel</Button>
                        <Button type="submit">Approve and Add Source</Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>

        {/* Reject Dialog */}
        <Dialog open={isRejectOpen} onOpenChange={setRejectOpen}>
            <DialogContent className="sm:max-w-md">
                <DialogHeader><DialogTitle>Reject Submission</DialogTitle><DialogDescription>Provide a reason for rejecting this submission.</DialogDescription></DialogHeader>
                <form onSubmit={rejectForm.handleSubmit(onRejectSubmit)} className="space-y-4">
                    <div className="space-y-1">
                        <Label htmlFor="rejectionReason">Reason</Label>
                        <Textarea id="rejectionReason" {...rejectForm.register('rejectionReason')} />
                        {rejectForm.formState.errors.rejectionReason && <p className="text-xs text-destructive">{rejectForm.formState.errors.rejectionReason.message}</p>}
                    </div>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => setRejectOpen(false)}>Cancel</Button>
                        <Button type="submit" variant="destructive">Confirm Rejection</Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
    