'use client';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MoreHorizontal, PlusCircle } from "lucide-react";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useCollection, useFirestore, useMemoFirebase, setDocumentNonBlocking, addDocumentNonBlocking, deleteDocumentNonBlocking } from '@/firebase';
import { collection, doc } from "firebase/firestore";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Skeleton } from "../ui/skeleton";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import type { Plan } from "@/lib/types";
import { Textarea } from "../ui/textarea";

const planSchema = z.object({
  name: z.string().min(1, "Name is required"),
  price: z.coerce.number().min(0, "Price must be a positive number"),
  currency: z.string().min(2, "Currency code is required (e.g., BDT)"),
  duration: z.enum(['monthly', 'yearly']),
  features: z.string().min(1, "At least one feature is required"),
});

type PlanFormValues = z.infer<typeof planSchema>;

export function SubscriptionManagement() {
  const { toast } = useToast();
  const firestore = useFirestore();
  
  const [isDialogOpen, setDialogOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<Plan | null>(null);

  const plansQuery = useMemoFirebase(() => collection(firestore, 'plans'), [firestore]);
  const { data: plans, isLoading: plansLoading } = useCollection<Plan>(plansQuery);
  
  const { register, handleSubmit, control, reset, formState: { errors } } = useForm<PlanFormValues>({
    resolver: zodResolver(planSchema),
    defaultValues: {
      name: '',
      price: 0,
      currency: 'BDT',
      duration: 'monthly',
      features: '',
    }
  });
  
  useEffect(() => {
    if(editingPlan) {
      reset({
        ...editingPlan,
        features: editingPlan.features.join('\n'),
      });
    } else {
      reset({
        name: '',
        price: 0,
        currency: 'BDT',
        duration: 'monthly',
        features: '',
      });
    }
  }, [editingPlan, reset]);

  const handleDialogOpen = (plan: Plan | null = null) => {
    setEditingPlan(plan);
    setDialogOpen(true);
  }

  const handleDelete = (planId: string) => {
    const planDocRef = doc(firestore, 'plans', planId);
    deleteDocumentNonBlocking(planDocRef);
    toast({
      title: 'Plan Deleted',
      description: 'The subscription plan has been removed.',
    });
  }
  
  const onSubmit = (data: PlanFormValues) => {
    const planData = {
      ...data,
      features: data.features.split('\n').filter(f => f.trim() !== ''),
    }

    if (editingPlan) {
      const planDocRef = doc(firestore, 'plans', editingPlan.id);
      setDocumentNonBlocking(planDocRef, planData, { merge: true });
      toast({ title: 'Plan Updated', description: `${data.name} has been updated.` });
    } else {
      const plansColRef = collection(firestore, 'plans');
      addDocumentNonBlocking(plansColRef, planData);
      toast({ title: 'Plan Created', description: `New plan "${data.name}" has been added.` });
    }
    setDialogOpen(false);
    setEditingPlan(null);
  };

  const PlansTable = () => {
    if (plansLoading) {
      return (
        <div className="space-y-2 mt-4">
          {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
        </div>
      );
    }

    if (!plans || plans.length === 0) {
      return (
        <div className="mt-4 p-8 text-center text-muted-foreground border-2 border-dashed rounded-lg">
          <h3 className="text-lg font-semibold">No Subscription Plans Found</h3>
          <p className="mt-1 text-sm">Create a new plan to get started.</p>
        </div>
      );
    }

    return (
       <div className="rounded-md border mt-4">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Plan Name</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Duration</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {plans.map(plan => (
              <TableRow key={plan.id}>
                <TableCell className="font-medium">{plan.name}</TableCell>
                <TableCell>{plan.price} {plan.currency}</TableCell>
                <TableCell className="capitalize">{plan.duration}</TableCell>
                <TableCell className="text-right">
                   <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleDialogOpen(plan)}>Edit</DropdownMenuItem>
                      <DropdownMenuItem className="text-destructive" onClick={() => handleDelete(plan.id)}>Delete</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
       </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
              <div>
                  <CardTitle>Subscription Plan Management</CardTitle>
                  <CardDescription>Create and manage premium subscription plans for your users.</CardDescription>
              </div>
              <Dialog open={isDialogOpen} onOpenChange={(open) => { setDialogOpen(open); if(!open) setEditingPlan(null); }}>
                <DialogTrigger asChild>
                  <Button onClick={() => handleDialogOpen()}>
                      <PlusCircle className="w-4 h-4 mr-2" />
                      Create New Plan
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                  <form onSubmit={handleSubmit(onSubmit)}>
                      <DialogHeader>
                        <DialogTitle>{editingPlan ? 'Edit' : 'Create'} Subscription Plan</DialogTitle>
                        <DialogDescription>
                          Configure a plan with special features for your users.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4 max-h-[65vh] overflow-y-auto pr-6">
                        <div className="space-y-1">
                          <Label htmlFor="name">Plan Name</Label>
                          <Input id="name" placeholder="e.g., Premium" {...register('name')} />
                          {errors.name && <p className="text-xs text-destructive">{errors.name.message}</p>}
                        </div>
                         <div className="grid grid-cols-3 gap-4">
                           <div className="space-y-1 col-span-2">
                            <Label htmlFor="price">Price</Label>
                            <Input id="price" type="number" {...register('price')} />
                             {errors.price && <p className="text-xs text-destructive">{errors.price.message}</p>}
                          </div>
                           <div className="space-y-1">
                            <Label htmlFor="currency">Currency</Label>
                            <Input id="currency" {...register('currency')} />
                             {errors.currency && <p className="text-xs text-destructive">{errors.currency.message}</p>}
                          </div>
                         </div>
                         <div className="space-y-1">
                            <Label htmlFor="duration">Duration</Label>
                            <Controller
                              control={control}
                              name="duration"
                              render={({ field }) => (
                                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                                      <SelectTrigger>
                                          <SelectValue placeholder="Select duration" />
                                      </SelectTrigger>
                                      <SelectContent>
                                          <SelectItem value="monthly">Monthly</SelectItem>
                                          <SelectItem value="yearly">Yearly</SelectItem>
                                      </SelectContent>
                                  </Select>
                              )}
                            />
                        </div>
                         <div className="space-y-1">
                          <Label htmlFor="features">Features (one per line)</Label>
                          <Textarea id="features" placeholder="e.g., Ad-free experience" {...register('features')} />
                          {errors.features && <p className="text-xs text-destructive">{errors.features.message}</p>}
                        </div>
                      </div>
                      <DialogFooter>
                        <Button type="submit">Save Plan</Button>
                      </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <PlansTable />
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>User Subscriptions</CardTitle>
          <CardDescription>View and manage all active user subscriptions.</CardDescription>
        </CardHeader>
        <CardContent>
           <div className="mt-4 p-8 text-center text-muted-foreground border-2 border-dashed rounded-lg">
                <p>User subscriptions will be listed here.</p>
           </div>
        </CardContent>
      </Card>
    </div>
  );
}
