'use client';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MoreHorizontal, PlusCircle, Tv } from "lucide-react";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useCollection, useFirestore, useMemoFirebase, setDocumentNonBlocking, addDocumentNonBlocking, deleteDocumentNonBlocking } from '@/firebase';
import { collection, doc } from "firebase/firestore";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Skeleton } from "../ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { Switch } from "../ui/switch";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { tvChannelCategories } from "@/lib/types";

const tvChannelSchema = z.object({
  name: z.string().min(1, "Name is required"),
  logoUrl: z.string().url("Must be a valid URL"),
  websiteUrl: z.string().url("Must be a valid URL"),
  imageHint: z.string().optional(),
  category: z.enum(tvChannelCategories),
  isActive: z.boolean(),
});

type TVChannelFormValues = z.infer<typeof tvChannelSchema>;
type TVChannel = TVChannelFormValues & { id: string };

export function TVChannelManagement() {
  const { toast } = useToast();
  const firestore = useFirestore();
  
  const [isDialogOpen, setDialogOpen] = useState(false);
  const [editingChannel, setEditingChannel] = useState<TVChannel | null>(null);

  const channelsQuery = useMemoFirebase(() => collection(firestore, 'tv_channels'), [firestore]);
  const { data: channels, isLoading: channelsLoading } = useCollection<TVChannel>(channelsQuery);

  const { register, handleSubmit, control, reset, formState: { errors } } = useForm<TVChannelFormValues>({
    resolver: zodResolver(tvChannelSchema),
    defaultValues: {
      name: '',
      logoUrl: '',
      websiteUrl: '',
      imageHint: '',
      category: 'National',
      isActive: true,
    }
  });
  
  useEffect(() => {
    if(editingChannel) {
      reset(editingChannel);
    } else {
      reset({
        name: '',
        logoUrl: '',
        websiteUrl: '',
        imageHint: '',
        category: 'National',
        isActive: true,
      });
    }
  }, [editingChannel, reset]);

  const handleDialogOpen = (channel: TVChannel | null = null) => {
    setEditingChannel(channel);
    setDialogOpen(true);
  }

  const handleDelete = (channelId: string) => {
    const channelDocRef = doc(firestore, 'tv_channels', channelId);
    deleteDocumentNonBlocking(channelDocRef);
    toast({
      title: 'TV Channel Deleted',
      description: 'The TV channel has been removed.',
    });
  }
  
  const onSubmit = (data: TVChannelFormValues) => {
    const channelData = { ...data };
    if (!channelData.imageHint) {
        channelData.imageHint = `${data.name} logo`;
    }

    if (editingChannel) {
      const channelDocRef = doc(firestore, 'tv_channels', editingChannel.id);
      setDocumentNonBlocking(channelDocRef, channelData, { merge: true });
      toast({ title: 'TV Channel Updated', description: `${data.name} has been updated.` });
    } else {
      const channelsColRef = collection(firestore, 'tv_channels');
      addDocumentNonBlocking(channelsColRef, channelData);
      toast({ title: 'TV Channel Added', description: `${data.name} has been added.` });
    }
    setDialogOpen(false);
    setEditingChannel(null);
  };
  
  const ChannelsTable = () => {
    if (channelsLoading) {
      return (
        <div className="space-y-2 mt-4">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      )
    }

    if (!channels || channels.length === 0) {
      return (
        <div className="mt-4 p-8 text-center text-muted-foreground border-2 border-dashed rounded-lg">
          <Tv className="mx-auto h-12 w-12" />
          <h3 className="mt-4 text-lg font-semibold">No TV Channels Found</h3>
          <p className="mt-1 text-sm">Add a new TV channel to get started.</p>
        </div>
      );
    }

    return (
       <div className="rounded-md border mt-4">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {channels.map(channel => (
              <TableRow key={channel.id}>
                <TableCell>
                  <div className="flex items-center gap-4">
                    <Avatar className="h-10 w-10 border">
                      <AvatarImage src={channel.logoUrl} alt={channel.name} />
                      <AvatarFallback><Tv/></AvatarFallback>
                    </Avatar>
                    <span className="font-medium">{channel.name}</span>
                  </div>
                </TableCell>
                <TableCell>{channel.category}</TableCell>
                <TableCell>{channel.isActive ? 'Active' : 'Inactive'}</TableCell>
                <TableCell className="text-right">
                   <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleDialogOpen(channel)}>Edit</DropdownMenuItem>
                      <DropdownMenuItem className="text-destructive" onClick={() => handleDelete(channel.id)}>Delete</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
       </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
            <div>
                <CardTitle>TV Channel Management</CardTitle>
                <CardDescription>Add new TV channels or update existing ones.</CardDescription>
            </div>
            <Dialog open={isDialogOpen} onOpenChange={(open) => { setDialogOpen(open); if(!open) setEditingChannel(null); }}>
              <DialogTrigger asChild>
                <Button onClick={() => handleDialogOpen()}>
                    <PlusCircle className="w-4 h-4 mr-2" />
                    Add New Channel
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                 <form onSubmit={handleSubmit(onSubmit)}>
                    <DialogHeader>
                      <DialogTitle>{editingChannel ? 'Edit' : 'Add'} TV Channel</DialogTitle>
                      <DialogDescription>
                        Fill in the details for the TV channel.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4 max-h-[65vh] overflow-y-auto pr-6">
                      <div className="space-y-1">
                        <Label htmlFor="name">Name</Label>
                        <Input id="name" {...register('name')} />
                        {errors.name && <p className="text-xs text-destructive">{errors.name.message}</p>}
                      </div>
                       <div className="space-y-1">
                        <Label htmlFor="logoUrl">Logo URL</Label>
                        <Input id="logoUrl" {...register('logoUrl')} />
                        {errors.logoUrl && <p className="text-xs text-destructive">{errors.logoUrl.message}</p>}
                      </div>
                       <div className="space-y-1">
                        <Label htmlFor="websiteUrl">Website URL</Label>
                        <Input id="websiteUrl" {...register('websiteUrl')} />
                        {errors.websiteUrl && <p className="text-xs text-destructive">{errors.websiteUrl.message}</p>}
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="imageHint">Image Hint (Optional)</Label>
                        <Input id="imageHint" {...register('imageHint')} placeholder="e.g., Channel i logo"/>
                        {errors.imageHint && <p className="text-xs text-destructive">{errors.imageHint.message}</p>}
                      </div>
                      <div className="space-y-1">
                          <Label htmlFor="category">Category</Label>
                          <Controller
                            control={control}
                            name="category"
                            render={({ field }) => (
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Select a category" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {tvChannelCategories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                                    </SelectContent>
                                </Select>
                            )}
                          />
                          {errors.category && <p className="text-xs text-destructive">{errors.category.message}</p>}
                      </div>
                      <div className="flex items-center space-x-2">
                         <Controller
                            control={control}
                            name="isActive"
                            render={({ field }) => (
                                <Switch id="isActive" checked={field.value} onCheckedChange={field.onChange} />
                            )}
                          />
                        <Label htmlFor="isActive">Is Active</Label>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button type="submit">Save Channel</Button>
                    </DialogFooter>
                 </form>
              </DialogContent>
            </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <ChannelsTable />
      </CardContent>
    </Card>
  );
}
