'use client';

import { useCollection, useFirestore, setDocumentNonBlocking, deleteDocumentNonBlocking, useMemoFirebase } from '@/firebase';
import { collection, doc } from 'firebase/firestore';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { MoreHorizontal, User as UserIcon } from 'lucide-react';
import { useMemo } from 'react';
import { Skeleton } from '../ui/skeleton';
import { useToast } from '@/hooks/use-toast';

export function UserManagementTable() {
  const firestore = useFirestore();
  const { toast } = useToast();

  const usersQuery = useMemoFirebase(() => collection(firestore, 'users'), [firestore]);
  const adminsQuery = useMemoFirebase(() => collection(firestore, 'roles_admin'), [firestore]);

  const { data: users, isLoading: usersLoading } = useCollection(usersQuery);
  const { data: admins, isLoading: adminsLoading } = useCollection(adminsQuery);

  const adminIds = useMemo(() => new Set(admins?.map(admin => admin.id)), [admins]);

  const combinedUsers = useMemo(() => {
    if (!users) return [];
    return users.map(user => ({
      ...user,
      isAdmin: adminIds.has(user.id),
    })).sort((a, b) => {
        // Sort by admin, then by name
        if (a.isAdmin && !b.isAdmin) return -1;
        if (!a.isAdmin && b.isAdmin) return 1;
        return (a.displayName || '').localeCompare(b.displayName || '');
    });
  }, [users, adminIds]);

  const handleRoleChange = (userId: string, currentIsAdmin: boolean, email: string) => {
    const adminRoleRef = doc(firestore, 'roles_admin', userId);
    if (currentIsAdmin) {
      deleteDocumentNonBlocking(adminRoleRef);
      toast({
        title: 'Admin Role Removed',
        description: `The user is no longer an admin.`,
      });
    } else {
      setDocumentNonBlocking(adminRoleRef, { email: email, assignedAt: new Date().toISOString() }, { merge: false });
      toast({
        title: 'Admin Role Granted',
        description: `The user is now an admin.`,
      });
    }
  };

  if (usersLoading || adminsLoading) {
    return (
        <div className="rounded-md border">
            <Table>
                <TableHeader>
                    <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {[...Array(3)].map((_, i) => (
                    <TableRow key={i}>
                        <TableCell>
                        <div className="flex items-center gap-4">
                            <Skeleton className="h-10 w-10 rounded-full" />
                            <div className='space-y-2'>
                            <Skeleton className="h-4 w-32" />
                            <Skeleton className="h-3 w-48" />
                            </div>
                        </div>
                        </TableCell>
                        <TableCell>
                        <Skeleton className="h-6 w-16 rounded-full" />
                        </TableCell>
                        <TableCell className="text-right">
                        <Skeleton className="h-8 w-8 ml-auto" />
                        </TableCell>
                    </TableRow>
                    ))}
                </TableBody>
            </Table>
      </div>
    );
  }
  
  if(!combinedUsers || combinedUsers.length === 0) {
    return <p className="text-muted-foreground text-center py-8">No users found.</p>
  }

  return (
    <div className="rounded-md border">
        <Table>
        <TableHeader>
            <TableRow>
            <TableHead>User</TableHead>
            <TableHead>Role</TableHead>
            <TableHead className="text-right">Actions</TableHead>
            </TableRow>
        </TableHeader>
        <TableBody>
            {combinedUsers?.map(user => (
            <TableRow key={user.id}>
                <TableCell>
                <div className="flex items-center gap-4">
                    <Avatar className="h-10 w-10">
                    <AvatarImage src={user.photoUrl || ''} />
                    <AvatarFallback>{user.displayName?.charAt(0) || <UserIcon />}</AvatarFallback>
                    </Avatar>
                    <div>
                    <div className="font-medium">{user.displayName}</div>
                    <div className="text-sm text-muted-foreground">{user.email}</div>
                    </div>
                </div>
                </TableCell>
                <TableCell>
                <Badge variant={user.isAdmin ? 'default' : 'secondary'}>
                    {user.isAdmin ? 'Admin' : 'User'}
                </Badge>
                </TableCell>
                <TableCell className="text-right">
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">User Actions</span>
                    </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleRoleChange(user.id, user.isAdmin, user.email)}>
                        {user.isAdmin ? 'Remove Admin Role' : 'Make Admin'}
                    </DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
                </TableCell>
            </TableRow>
            ))}
        </TableBody>
        </Table>
    </div>
  );
}
