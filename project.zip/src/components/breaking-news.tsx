'use client';

export function BreakingNews() {
  return null;
}
