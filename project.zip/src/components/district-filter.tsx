'use client';

import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

type DistrictFilterProps = {
  districts: string[];
};

export function DistrictFilter({ districts }: DistrictFilterProps) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const selectedDistrict = searchParams.get('district') || 'All';

  const handleValueChange = (value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set('category', 'Local');
    if (value === 'All') {
      params.delete('district');
    } else {
      params.set('district', value);
    }
    router.replace(`${pathname}?${params.toString()}`);
  };

  return (
    <div className="flex items-center gap-2">
      <Select onValueChange={handleValueChange} value={selectedDistrict}>
        <SelectTrigger className="w-full sm:w-[180px]">
          <SelectValue placeholder="Filter by District" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="All">All Districts</SelectItem>
          {districts.map(district => (
            <SelectItem key={district} value={district}>
              {district}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
