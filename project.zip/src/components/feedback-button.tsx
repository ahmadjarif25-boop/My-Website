'use client';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import { SidebarMenuButton } from '@/components/ui/sidebar';
import { MessageSquare, Send } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useFirestore, useUser, setDocumentNonBlocking } from '@/firebase';
import { collection, serverTimestamp, doc } from 'firebase/firestore';

const feedbackSchema = z.object({
  name: z.string().optional(),
  email: z.string().email({ message: 'Please enter a valid email.' }).optional().or(z.literal('')),
  feedback: z.string().min(10, { message: 'Feedback must be at least 10 characters long.' }),
});

type FeedbackFormValues = z.infer<typeof feedbackSchema>;

export function FeedbackButton() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const firestore = useFirestore();
  const { user } = useUser();

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<FeedbackFormValues>({
    resolver: zodResolver(feedbackSchema),
    defaultValues: {
      name: user?.displayName || '',
      email: user?.email || '',
      feedback: '',
    },
  });

  const onSubmit = async (data: FeedbackFormValues) => {
    if (!user) {
        toast({
            title: "Authentication Required",
            description: "You must be logged in to submit feedback.",
            variant: "destructive"
        });
        return;
    }
    
    try {
      const feedbackColRef = collection(firestore, 'feedbacks');
      const newDocRef = doc(feedbackColRef); // Generate ID for both docs
      const feedbackId = newDocRef.id;

      const userFeedbackDocRef = doc(firestore, 'users', user.uid, 'feedbacks', feedbackId);

      const feedbackData = {
        id: feedbackId,
        ...data,
        userId: user.uid,
        submittedAt: serverTimestamp(),
      };
      
      // Write to both locations
      await setDocumentNonBlocking(newDocRef, feedbackData, {});
      await setDocumentNonBlocking(userFeedbackDocRef, feedbackData, {});

      toast({
        title: 'Feedback Submitted!',
        description: "Thank you for your valuable input. You can see admin replies on your profile page.",
      });
      reset();
      setOpen(false);

    } catch (error: any) {
      // The global error handler (`FirebaseErrorListener`) will catch permission errors.
      // We only toast for other potential errors.
      if (error.name !== 'FirebaseError') {
         toast({
            title: 'Submission Failed',
            description: error.message || 'An unexpected error occurred.',
            variant: 'destructive',
         });
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <SidebarMenuButton tooltip={{ children: "Feedback" }}>
          <MessageSquare />
          <span className="group-data-[state=collapsed]:hidden">Feedback</span>
        </SidebarMenuButton>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Submit Feedback</DialogTitle>
          <DialogDescription>
            We would love to hear your thoughts, suggestions, or bug reports.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name (Optional)</Label>
            <Input id="name" {...register('name')} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email (Optional)</Label>
            <Input id="email" {...register('email')} />
            {errors.email && <p className="text-xs text-destructive">{errors.email.message}</p>}
          </div>
          <div className="space-y-2">
            <Label htmlFor="feedback">Feedback</Label>
            <Textarea id="feedback" {...register('feedback')} />
            {errors.feedback && <p className="text-xs text-destructive">{errors.feedback.message}</p>}
          </div>
          <DialogFooter>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Submitting...' : 'Submit Feedback'}
              <Send className='ml-2' />
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
