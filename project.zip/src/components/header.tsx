'use client';

import { useRouter } from 'next/navigation';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { User } from 'lucide-react';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { useAuth, useUser, useCollection, useFirestore, useMemoFirebase } from '@/firebase';
import { initiateSignOut } from '@/firebase/non-blocking-login';
import { Skeleton } from './ui/skeleton';
import { Logo } from './icons';
import Link from 'next/link';
import { collection, query, where } from 'firebase/firestore';
import type { Feedback } from '@/lib/types';


export function Header() {
  const router = useRouter();
  const auth = useAuth();
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();

  const unreadFeedbackQuery = useMemoFirebase(() => {
    if (!user) return null;
    // Simplified query to avoid needing a composite index, which can cause permission errors if not present.
    // The filtering for adminReply is now done on the client side.
    return query(
      collection(firestore, 'users', user.uid, 'feedbacks'),
      where('userHasSeenReply', '==', false)
    );
  }, [firestore, user]);

  const { data: unreadFeedbacks } = useCollection<Feedback>(unreadFeedbackQuery);
  // Client-side filtering to check if there's actually a reply.
  const hasNewNotification = unreadFeedbacks ? unreadFeedbacks.some(fb => !!fb.adminReply) : false;

  const handleLogout = () => {
    initiateSignOut(auth);
    router.push('/login');
  };

  const UserMenu = () => {
    if (isUserLoading) {
      return <Skeleton className="h-8 w-8 rounded-full" />;
    }

    if (!user) {
      return (
        <div className="flex items-center gap-2">
           <Button variant="outline" onClick={() => router.push('/login')}>Log In</Button>
           <Button onClick={() => router.push('/signup')} variant="secondary" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary">Sign Up</Button>
        </div>
      );
    }

    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="relative h-8 w-8 rounded-full">
            <Avatar className="h-8 w-8 border-2 border-primary-foreground/50 bg-background text-primary">
              <AvatarImage src={user.photoURL || ''} alt={user.displayName || 'User'} />
              <AvatarFallback>
                <User />
              </AvatarFallback>
            </Avatar>
            {hasNewNotification && (
              <span className="absolute top-0 right-0 flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-destructive opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-destructive"></span>
              </span>
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56" align="end" forceMount>
          <DropdownMenuLabel className="font-normal">
            <div className="flex flex-col space-y-1">
              <p className="text-sm font-medium leading-none">{user.displayName || 'User'}</p>
              <p className="text-xs leading-none text-muted-foreground">
                {user.email}
              </p>
            </div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem onSelect={() => router.push('/profile')}>
            Profile
            {hasNewNotification && <span className="ml-auto h-2 w-2 rounded-full bg-destructive" />}
            </DropdownMenuItem>
          <DropdownMenuItem onSelect={() => router.push('/admin')}>Admin</DropdownMenuItem>
          <DropdownMenuItem onSelect={() => router.push('/settings')}>Settings</DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onSelect={handleLogout}>Log out</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
  };

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b border-primary/20 bg-primary px-4 text-primary-foreground shadow-md sm:px-6">
      <SidebarTrigger className="md:hidden" />
      <Link href="/" className="hidden items-center gap-2 md:flex">
        <Logo className="h-7 w-7 text-primary-foreground" />
        <h1 className="text-lg font-bold tracking-tight text-primary-foreground">BD News Hub</h1>
      </Link>
      <div className="flex w-full items-center justify-end gap-2">
        <UserMenu />
      </div>
    </header>
  );
}
