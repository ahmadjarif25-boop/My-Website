import type { SVGProps } from 'react';

export function Logo(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
      <path d="M12 12c2.761 0 5-2.239 5-5s-2.239-5-5-5" />
      <path d="M12 12c-2.761 0-5 2.239-5 5s2.239 5 5 5" />
      <line x1="2" y1="12" x2="22" y2="12" />
    </svg>
  );
}
