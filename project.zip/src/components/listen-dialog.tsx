'use client';

import { useState, type ReactNode } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import type { NewsArticle } from '@/lib/types';
import { getAudioForText } from '@/app/actions';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';

type ListenDialogProps = {
  article: NewsArticle;
  children: ReactNode;
};

export function ListenDialog({ article, children }: ListenDialogProps) {
  const [open, setOpen] = useState(false);
  const [audioDataUri, setAudioDataUri] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleListen = async () => {
    setIsLoading(true);
    setAudioDataUri('');

    const formData = new FormData();
    // To keep generation fast and costs low, we'll only convert the title and first few sentences.
    const textToSpeak = `${article.title}. ${article.content.split('.').slice(0, 3).join('.')}.`;
    formData.append('text', textToSpeak);

    const result = await getAudioForText(formData);

    if (result.error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: result.error,
      });
    } else if (result.audio) {
      setAudioDataUri(result.audio);
    }
    setIsLoading(false);
  };

  const handleOpenChange = (isOpen: boolean) => {
    setOpen(isOpen);
    if (isOpen && !audioDataUri) {
      handleListen();
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Listen to Article</DialogTitle>
          <DialogDescription className="font-headline">{article.title}</DialogDescription>
        </DialogHeader>
        <div className="p-4 flex items-center justify-center">
          {isLoading && (
            <div className="space-y-2 w-full">
              <Skeleton className="h-12 w-full" />
              <p className="text-sm text-center text-muted-foreground">Generating audio, please wait...</p>
            </div>
          )}
          {audioDataUri && (
            <audio controls autoPlay src={audioDataUri} className="w-full">
              Your browser does not support the audio element.
            </audio>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
