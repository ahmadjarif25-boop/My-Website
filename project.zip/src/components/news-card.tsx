'use client';

import Image from 'next/image';
import {
  Card,
  CardContent,
  CardFooter,
  CardTitle,
} from '@/components/ui/card';
import type { NewsArticle } from '@/lib/types';
import { SummarizeDialog } from '@/components/summarize-dialog';
import { Button } from './ui/button';
import { Bookmark, Share2, Sparkles, Headphones } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { ListenDialog } from './listen-dialog';
import Link from 'next/link';

type NewsCardProps = {
  article: NewsArticle;
};

export function NewsCard({ article }: NewsCardProps) {
  const { toast } = useToast();

  const handleShare = async (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    if (navigator.share) {
      try {
        await navigator.share({
          title: article.title,
          text: `Check out this article from ${article.source}`,
          url: article.link,
        });
      } catch (error) {
        console.error('Error sharing:', error);
        toast({
          variant: 'destructive',
          title: 'Could not share',
          description: 'There was an error trying to share this article.',
        });
      }
    } else {
       // Fallback for browsers that don't support the Web Share API
      navigator.clipboard.writeText(article.link);
      toast({
        title: 'Link Copied',
        description: 'Article link has been copied to your clipboard.',
      });
    }
  };

  const handleBookmark = (e: React.MouseEvent<HTMLButtonElement>) => {
     e.preventDefault();
     toast({
        title: 'Coming Soon!',
        description: 'Bookmark functionality will be available in a future update.',
      });
  }

  return (
    <Link href={article.link} target="_blank" rel="noopener noreferrer" className="group block h-full">
      <Card className="flex h-full flex-col">
        <div className="relative aspect-square w-full">
          <Image
            src={article.imageUrl}
            alt={article.title}
            data-ai-hint={article.imageHint}
            fill
            className="object-contain"
          />
        </div>
        <CardContent className="flex flex-1 flex-col p-4">
          <p className="mb-2 text-xs font-medium text-primary">
            {article.source}
          </p>
          <CardTitle className="mb-2 flex-grow text-lg font-semibold leading-snug text-foreground font-headline group-hover:text-primary transition-colors">
            {article.title}
          </CardTitle>
          <p className="text-xs text-muted-foreground">
            {article.date}
          </p>
        </CardContent>
        <CardFooter className="p-2 pt-0">
          <div className="flex w-full items-center justify-end space-x-1">
            <SummarizeDialog article={article}>
               <Button variant="ghost" size="icon" onClick={(e) => e.preventDefault()}>
                  <Sparkles className="h-4 w-4 text-muted-foreground" />
                  <span className="sr-only">AI Summary</span>
              </Button>
            </SummarizeDialog>
             <ListenDialog article={article}>
                <Button variant="ghost" size="icon" onClick={(e) => e.preventDefault()}>
                    <Headphones className="h-4 w-4 text-muted-foreground" />
                    <span className="sr-only">Listen to Article</span>
                </Button>
              </ListenDialog>
            <Button variant="ghost" size="icon" onClick={handleBookmark}>
              <Bookmark className="h-4 w-4 text-muted-foreground" />
              <span className="sr-only">Bookmark</span>
            </Button>
            <Button variant="ghost" size="icon" onClick={handleShare}>
              <Share2 className="h-4 w-4 text-muted-foreground" />
              <span className="sr-only">Share</span>
            </Button>
          </div>
        </CardFooter>
      </Card>
    </Link>
  );
}
