'use client';
import { useState } from 'react';
import { NewsGrid } from '@/components/news-grid';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { categories, categoryDisplayMap, type NewsArticle } from '@/lib/types';

type NewsTabsProps = {
  articles: NewsArticle[];
};

export function NewsTabs({ articles }: NewsTabsProps) {
  const [activeTab, setActiveTab] = useState('All');

  const filteredArticles =
    activeTab === 'All'
      ? articles
      : articles.filter((article) => article.category === activeTab);

  return (
    <Tabs defaultValue="All" onValueChange={setActiveTab}>
      <div className="mb-6 flex items-center justify-between border-b">
        <h2 className="text-2xl font-bold md:text-3xl">Latest News</h2>
        <TabsList className="hidden sm:flex">
          <TabsTrigger value="All">All</TabsTrigger>
          {categories.map((category) => (
            <TabsTrigger key={category} value={category}>
              {categoryDisplayMap[category] || category}
            </TabsTrigger>
          ))}
        </TabsList>
      </div>

      <TabsContent value={activeTab}>
        <NewsGrid articles={filteredArticles} />
      </TabsContent>
    </Tabs>
  );
}
