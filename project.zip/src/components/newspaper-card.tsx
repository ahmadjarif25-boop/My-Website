'use client';

import type { Newspaper } from '@/lib/types';
import { cn } from '@/lib/utils';
import Link from 'next/link';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { useFirestore } from '@/firebase';
import { doc, setDoc, increment } from 'firebase/firestore';

export function NewspaperCard({ newspaper }: { newspaper: Newspaper }) {
  const firestore = useFirestore();

  const handleNewspaperClick = () => {
    // Fire-and-forget analytics update. No need to await.
    if (!firestore || !newspaper.id) return;
    try {
      const viewCountRef = doc(firestore, 'newspaper_view_counts', newspaper.id);
      const data = { 
        newspaperName: newspaper.name,
        nameBn: newspaper.nameBn || null,
        logoUrl: newspaper.logoUrl,
        viewCount: increment(1) 
      };
      // This is a low-risk, non-user-facing operation.
      // We use setDoc with merge:true to either create the document or update it.
      setDoc(viewCountRef, data, { merge: true });
    } catch (error) {
      console.error("Failed to update view count:", error); // Log silently if it fails
    }
  };
  
  const isClickable = newspaper.websiteUrl && newspaper.websiteUrl !== '#';
  
  const cardContent = (
    <Card className={cn("flex h-full flex-col items-center justify-center overflow-hidden p-4 group", isClickable ? "cursor-pointer" : "cursor-not-allowed opacity-60")}>
      <CardContent className="p-0 flex items-center justify-center flex-grow h-24 w-full">
        <div className="relative h-full w-full">
          <img
            src={newspaper.logoUrl}
            alt={`${newspaper.name} logo`}
            className="w-full h-full object-contain"
          />
        </div>
      </CardContent>
       <CardFooter className="p-2 pb-0 mt-2 flex-col">
        <p className="text-sm font-semibold text-center text-card-foreground">{newspaper.name}</p>
        {newspaper.nameBn && <p className="text-xs text-center text-muted-foreground font-bengali">{newspaper.nameBn}</p>}
        {newspaper.district && (
          <p className="text-xs text-muted-foreground">{newspaper.district}</p>
        )}
      </CardFooter>
    </Card>
  );

  if (isClickable) {
    return (
      <Link 
        href={newspaper.websiteUrl}
        target="_blank" 
        rel="noopener noreferrer" 
        className="h-full"
        onClick={handleNewspaperClick}
      >
        {cardContent}
      </Link>
    );
  }

  return <div className="h-full">{cardContent}</div>;
}
