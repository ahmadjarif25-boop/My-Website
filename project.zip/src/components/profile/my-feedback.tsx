'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useCollection, useFirestore, useUser, useMemoFirebase, updateDocumentNonBlocking } from '@/firebase';
import { collection, query, orderBy, Timestamp, doc } from 'firebase/firestore';
import { Skeleton } from "../ui/skeleton";
import type { Feedback } from "@/lib/types";
import { MessageSquare } from "lucide-react";
import { formatDistanceToNow } from 'date-fns';
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { useEffect } from "react";

export function MyFeedback() {
  const { user } = useUser();
  const firestore = useFirestore();

  const feedbackQuery = useMemoFirebase(() => {
    if (!user) return null;
    return query(
      collection(firestore, 'users', user.uid, 'feedbacks'), 
      orderBy('submittedAt', 'desc')
    );
  }, [firestore, user]);

  const { data: feedbacks, isLoading } = useCollection<Feedback>(feedbackQuery);
  
  useEffect(() => {
    if (!firestore || !user || !feedbacks || feedbacks.length === 0) {
      return;
    }

    const unreadReplies = feedbacks.filter(fb => fb.adminReply && !fb.userHasSeenReply);

    if (unreadReplies.length > 0) {
      const updatePromises = unreadReplies.map(fb => {
        const feedbackRef = doc(firestore, 'users', user.uid, 'feedbacks', fb.id);
        return updateDocumentNonBlocking(feedbackRef, { userHasSeenReply: true });
      });
      Promise.all(updatePromises).catch(console.error); // Log errors if updates fail
    }
  }, [feedbacks, firestore, user]);

  return (
    <Card>
      <CardHeader>
        <CardTitle>My Feedback</CardTitle>
        <CardDescription>Track your submitted feedback and see admin replies.</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-24 w-full" />
          </div>
        ) : !feedbacks || feedbacks.length === 0 ? (
          <div className="text-sm text-muted-foreground text-center py-4 flex flex-col items-center">
            <MessageSquare className="w-10 h-10 mb-2" />
            <p>You haven't submitted any feedback yet.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {feedbacks.map(fb => (
              <div key={fb.id} className="space-y-3">
                <div>
                    <p className="text-sm text-muted-foreground">You said {fb.submittedAt instanceof Timestamp ? formatDistanceToNow(fb.submittedAt.toDate(), { addSuffix: true }) : 'recently'}:</p>
                    <p className="mt-1 p-3 rounded-md bg-muted text-sm">{fb.feedback}</p>
                </div>
                {fb.adminReply && (
                   <div className="pl-6 border-l-2 border-primary ml-4">
                      <div className="flex items-center gap-2">
                        <Avatar className="h-7 w-7 border-2 border-primary/50">
                            <AvatarImage src={undefined} />
                            <AvatarFallback className="text-xs bg-primary text-primary-foreground">{fb.repliedBy?.charAt(0) || 'A'}</AvatarFallback>
                        </Avatar>
                        <div>
                             <p className="text-sm font-semibold">{fb.repliedBy || 'Admin'} replied {fb.repliedAt instanceof Timestamp ? formatDistanceToNow(fb.repliedAt.toDate(), { addSuffix: true }) : ''}</p>
                        </div>
                      </div>
                      <p className="mt-2 p-3 rounded-md bg-background border text-sm">{fb.adminReply}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
