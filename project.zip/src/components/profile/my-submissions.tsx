'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useCollection, useFirestore, useUser, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, Timestamp } from 'firebase/firestore';
import { Skeleton } from "../ui/skeleton";
import type { SubmittedSource } from "@/lib/types";
import { Badge } from "../ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { Newspaper } from "lucide-react";
import { formatDistanceToNow } from 'date-fns';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "../ui/tooltip";

export function MySubmissions() {
  const { user } = useUser();
  const firestore = useFirestore();

  const submissionsQuery = useMemoFirebase(() => {
    if (!user) return null;
    return query(collection(firestore, 'users', user.uid, 'submissions'), orderBy('submittedAt', 'desc'));
  }, [firestore, user]);

  const { data: submissions, isLoading } = useCollection<SubmittedSource>(submissionsQuery);

  const StatusBadge = ({ status, reason }: { status: SubmittedSource['status']; reason?: string }) => {
    const variant = {
      pending: 'secondary',
      approved: 'default',
      rejected: 'destructive',
    }[status] as "secondary" | "default" | "destructive" | undefined;

    if (!variant) return null;

    const badge = <Badge variant={variant} className="capitalize">{status}</Badge>;
    
    if (status === 'rejected' && reason) {
      return (
        <TooltipProvider>
            <Tooltip>
                <TooltipTrigger>{badge}</TooltipTrigger>
                <TooltipContent>
                    <p className="max-w-xs">{reason}</p>
                </TooltipContent>
            </Tooltip>
        </TooltipProvider>
      );
    }
    return badge;
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>My Submissions</CardTitle>
        <CardDescription>Track the status of the newspapers you have submitted.</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        ) : !submissions || submissions.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">You haven't submitted any newspapers yet.</p>
        ) : (
          <div className="space-y-4">
            {submissions.map(sub => (
              <div key={sub.id} className="flex items-center justify-between rounded-md border p-3">
                <div className="flex items-center gap-4">
                    <Avatar className="h-10 w-10 border hidden sm:flex">
                        <AvatarImage src={sub.logoUrl} alt={sub.mediaName} />
                        <AvatarFallback><Newspaper className="h-5 w-5" /></AvatarFallback>
                    </Avatar>
                    <div>
                        <p className="font-semibold">{sub.mediaName}</p>
                        <p className="text-xs text-muted-foreground">
                            Submitted {sub.submittedAt instanceof Timestamp ? formatDistanceToNow(sub.submittedAt.toDate(), { addSuffix: true }) : 'recently'}
                        </p>
                    </div>
                </div>
                 <StatusBadge status={sub.status} reason={sub.rejectionReason} />
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
