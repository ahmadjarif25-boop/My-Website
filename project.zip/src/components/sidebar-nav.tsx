'use client';

import { usePathname, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Home, Newspaper, Building, Globe, Tv, Shield, Settings, PlusCircle, MessageSquare } from 'lucide-react';
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  useSidebar,
} from '@/components/ui/sidebar';
import { Logo } from './icons';
import { cn } from '@/lib/utils';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { FeedbackButton } from './feedback-button';

export function SidebarNav() {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const category = searchParams.get('category');
  const { setOpenMobile } = useSidebar();

  const isNewspapersPage = pathname.startsWith('/newspapers');
  const isTvChannelsPage = pathname === '/tv-channels';

  const handleLinkClick = () => {
    setOpenMobile(false);
  };

  return (
    <Sidebar collapsible="icon" variant="sidebar">
      <SidebarHeader className="hidden items-center gap-2 md:flex">
        <Logo className="h-7 w-7" />
        <h1 className="text-lg font-bold tracking-tight text-sidebar-foreground">
          <span className="group-data-[state=collapsed]:hidden">
            BD News Hub
          </span>
        </h1>
      </SidebarHeader>
      <SidebarContent className="p-2">
         <SidebarMenu>
          <SidebarMenuItem>
            <Accordion type="single" collapsible defaultValue="newspapers" className="w-full">
              <AccordionItem value="newspapers" className="border-none">
                <AccordionTrigger 
                  className={cn(
                    "w-full text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground rounded-md p-2 flex items-center gap-2 text-sm [&[data-state=open]>svg:last-child]:rotate-180",
                    (isNewspapersPage || pathname === '/') && 'bg-sidebar-accent'
                  )}
                >
                  <Newspaper className="h-4 w-4" />
                  <span className="group-data-[state=collapsed]:hidden">Newspapers</span>
                </AccordionTrigger>
                <AccordionContent className="p-0 pl-4 pt-1">
                   <SidebarMenu className="group-data-[state=collapsed]:hidden">
                      <SidebarMenuItem>
                        <Link href="/newspapers" className="w-full" onClick={handleLinkClick}>
                          <SidebarMenuButton
                              isActive={pathname === '/newspapers' && !category}
                              tooltip={{ children: "All Newspapers" }}
                            >
                              <Globe className="h-4 w-4" />
                              <span>All</span>
                            </SidebarMenuButton>
                        </Link>
                      </SidebarMenuItem>
                      <SidebarMenuItem>
                        <Link href="/newspapers?category=National" className="w-full" onClick={handleLinkClick}>
                          <SidebarMenuButton
                              isActive={isNewspapersPage && category === 'National'}
                              tooltip={{ children: "National Newspapers" }}
                            >
                              <Globe className="h-4 w-4" />
                              <span>National</span>
                            </SidebarMenuButton>
                        </Link>
                      </SidebarMenuItem>
                      <SidebarMenuItem>
                        <Link href="/newspapers?category=Local" className="w-full" onClick={handleLinkClick}>
                          <SidebarMenuButton
                              isActive={isNewspapersPage && category === 'Local'}
                              tooltip={{ children: "Local Newspapers" }}
                            >
                              <Building className="h-4 w-4" />
                              <span>Local</span>
                            </SidebarMenuButton>
                        </Link>
                      </SidebarMenuItem>
                      <SidebarMenuItem>
                        <Link href="/newspapers?category=English" className="w-full" onClick={handleLinkClick}>
                          <SidebarMenuButton
                              isActive={isNewspapersPage && category === 'English'}
                              tooltip={{ children: "English Newspapers" }}
                            >
                              <Globe className="h-4 w-4" />
                              <span>English</span>
                            </SidebarMenuButton>
                        </Link>
                      </SidebarMenuItem>
                       <SidebarMenuItem>
                        <Link href="/newspapers/submit" className="w-full" onClick={handleLinkClick}>
                          <SidebarMenuButton
                              isActive={pathname === '/newspapers/submit'}
                              tooltip={{ children: "Submit Newspaper" }}
                            >
                              <PlusCircle className="h-4 w-4" />
                              <span>Submit</span>
                            </SidebarMenuButton>
                        </Link>
                      </SidebarMenuItem>
                  </SidebarMenu>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </SidebarMenuItem>
           <SidebarMenuItem>
            <Accordion type="single" collapsible defaultValue="tv-channels" className="w-full">
              <AccordionItem value="tv-channels" className="border-none">
                <AccordionTrigger
                  className={cn(
                    "w-full text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground rounded-md p-2 flex items-center gap-2 text-sm [&[data-state=open]>svg:last-child]:rotate-180",
                    isTvChannelsPage && 'bg-sidebar-accent'
                  )}
                >
                  <Tv className="h-4 w-4" />
                  <span className="group-data-[state=collapsed]:hidden">TV Channels</span>
                </AccordionTrigger>
                <AccordionContent className="p-0 pl-4 pt-1">
                   <SidebarMenu className="group-data-[state=collapsed]:hidden">
                      <SidebarMenuItem>
                        <Link href="/tv-channels?category=All" className="w-full" onClick={handleLinkClick}>
                          <SidebarMenuButton
                              isActive={isTvChannelsPage && (category === 'All' || !category)}
                              tooltip={{ children: "All TV Channels" }}
                            >
                              <Globe className="h-4 w-4" />
                              <span>All</span>
                            </SidebarMenuButton>
                        </Link>
                      </SidebarMenuItem>
                      <SidebarMenuItem>
                        <Link href="/tv-channels?category=National" className="w-full" onClick={handleLinkClick}>
                          <SidebarMenuButton
                              isActive={isTvChannelsPage && category === 'National'}
                              tooltip={{ children: "National Channels" }}
                            >
                              <Globe className="h-4 w-4" />
                              <span>National</span>
                            </SidebarMenuButton>
                        </Link>
                      </SidebarMenuItem>
                      <SidebarMenuItem>
                        <Link href="/tv-channels?category=Local" className="w-full" onClick={handleLinkClick}>
                          <SidebarMenuButton
                              isActive={isTvChannelsPage && category === 'Local'}
                              tooltip={{ children: "Local Channels" }}
                            >
                              <Building className="h-4 w-4" />
                              <span>Local</span>
                            </SidebarMenuButton>
                        </Link>
                      </SidebarMenuItem>
                  </SidebarMenu>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <FeedbackButton />
          </SidebarMenuItem>
          <SidebarMenuItem>
            <Link href="/settings" className="w-full" onClick={handleLinkClick}>
              <SidebarMenuButton
                  isActive={pathname === '/settings'}
                  tooltip={{ children: "Settings" }}
                >
                  <Settings className="h-4 w-4" />
                  <span className="group-data-[state=collapsed]:hidden">Settings</span>
                </SidebarMenuButton>
            </Link>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <Link href="/admin" className="w-full" onClick={handleLinkClick}>
              <SidebarMenuButton
                  isActive={pathname === '/admin'}
                  tooltip={{ children: "Admin" }}
                >
                  <Shield className="h-4 w-4" />
                  <span className="group-data-[state=collapsed]:hidden">Admin</span>
                </SidebarMenuButton>
            </Link>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarContent>
    </Sidebar>
  );
}
