'use client';

import { useState, type ReactNode } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { NewsArticle } from '@/lib/types';
import { getSummary } from '@/app/actions';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';

type SummarizeDialogProps = {
  article: NewsArticle;
  children: ReactNode;
};

export function SummarizeDialog({ article, children }: SummarizeDialogProps) {
  const [open, setOpen] = useState(false);
  const [summary, setSummary] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSummarize = async () => {
    setIsLoading(true);
    setSummary('');

    const formData = new FormData();
    formData.append('articleContent', article.content);

    const result = await getSummary(formData);

    if (result.error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: result.error,
      });
    } else if (result.summary) {
      setSummary(result.summary);
    }
    setIsLoading(false);
  };

  const handleOpenChange = (isOpen: boolean) => {
    setOpen(isOpen);
    if (isOpen && !summary) {
      handleSummarize();
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>AI Summary</DialogTitle>
          <DialogDescription className="font-headline">{article.title}</DialogDescription>
        </DialogHeader>
        <ScrollArea className="h-64 w-full">
          <div className="p-4">
            {isLoading && (
              <div className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-full" />
              </div>
            )}
            {summary && <p className="text-sm">{summary}</p>}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
