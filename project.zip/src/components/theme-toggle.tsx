'use client';

import { useTheme } from 'next-themes';
import { Switch } from '@/components/ui/switch';
import { Moon, Sun } from 'lucide-react';

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();

  const isDark = theme === 'dark';

  const handleThemeChange = (checked: boolean) => {
    setTheme(checked ? 'dark' : 'light');
  };

  return (
    <div className="flex items-center space-x-2">
        <Sun className="h-5 w-5" />
      <Switch
        id="theme-switch"
        checked={isDark}
        onCheckedChange={handleThemeChange}
      />
      <Moon className="h-5 w-5" />
    </div>
  );
}
